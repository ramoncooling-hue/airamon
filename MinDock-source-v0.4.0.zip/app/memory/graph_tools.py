"""Portable graph exchange and integrity checks."""

from __future__ import annotations

import json
from collections import Counter

from .db import connect
from . import domain_profiles


def health(course: str | None = None) -> dict:
    conn = connect()
    try:
        args = []
        where = ''
        if course:
            where = ' WHERE co.name=?'
            args.append(course)
        nodes = conn.execute('''SELECT kp.id,kp.name,kp.kp_type,co.name AS course_name FROM kp
                                JOIN courses co ON co.id=kp.course_id''' + where, args).fetchall()
        ids = {row['id'] for row in nodes}
        edges = conn.execute('''SELECT e.id,e.from_kp,e.to_kp,e.kind
                               FROM kp_edges e JOIN kp a ON a.id=e.from_kp
                               JOIN kp b ON b.id=e.to_kp
                               JOIN courses ca ON ca.id=a.course_id
                               JOIN courses cb ON cb.id=b.course_id
                              WHERE (? IS NULL OR ca.name=? OR cb.name=?)''',
                            [course, course, course]).fetchall()
        profile = domain_profiles.public_profile(course or '')
        isolated = [dict(row) for row in nodes
                    if row['kp_type'] != 'section'
                    and not any(e['from_kp'] == row['id'] or e['to_kp'] == row['id'] for e in edges)]
        structural_placeholders = [dict(row) for row in nodes
                                   if row['kp_type'] == 'section'
                                   and not any(e['from_kp'] == row['id'] or e['to_kp'] == row['id'] for e in edges)]
        contract_rows = conn.execute('''SELECT kp.id,kp.name,kp.source,nm.domain,nm.status,nm.source_refs_json
                                       FROM kp JOIN courses co ON co.id=kp.course_id
                                       LEFT JOIN knowledge_node_meta nm ON nm.kp_id=kp.id
                                       WHERE (? IS NULL OR co.name=?)''', [course, course]).fetchall()
        contract_gaps = []
        for row in contract_rows:
            if not row['domain'] or row['domain'] != profile['id']:
                contract_gaps.append({'id': row['id'], 'name': row['name'], 'issue': '领域合同未匹配'})
            elif not json.loads(row['source_refs_json'] or '[]') and not str(row['source'] or '').strip():
                contract_gaps.append({'id': row['id'], 'name': row['name'], 'issue': '缺少溯源'})
        duplicates = [dict(row) for row in conn.execute('''SELECT co.name AS course_name,kp.name,COUNT(*) AS count
                                                            FROM kp JOIN courses co ON co.id=kp.course_id
                                                           WHERE (? IS NULL OR co.name=?)
                                                           GROUP BY kp.course_id,kp.name HAVING COUNT(*)>1''',
                                                         [course, course]).fetchall()]
        bad_edges = [dict(row) for row in conn.execute('''SELECT id,from_kp,to_kp,kind FROM kp_edges
                                                          WHERE from_kp NOT IN (SELECT id FROM kp)
                                                             OR to_kp NOT IN (SELECT id FROM kp)''').fetchall()]
        empty_relations = [dict(row) for row in conn.execute("SELECT id,from_name,to_name,kind,status FROM relation_candidates WHERE status='pending' AND (trim(from_name)='' OR trim(to_name)='')").fetchall()]
        unresolved = [dict(row) for row in conn.execute("""SELECT bl.id,b.course_a,b.kp_a,b.course_b,b.kp_b,bl.status
                                                            FROM bridge_links bl JOIN bridges b ON b.id=bl.bridge_id
                                                           WHERE bl.status!='resolved'""").fetchall()] if conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='bridge_links'").fetchone() else []
        return {'course': course or '全部课程', 'profile': profile, 'node_count': len(nodes), 'edge_count': len(edges),
                'isolated_nodes': isolated, 'structural_placeholders': structural_placeholders,
                'duplicate_nodes': duplicates,
                'dangling_edges': bad_edges, 'empty_relations': empty_relations,
                'unresolved_bridges': unresolved, 'contract_gaps': contract_gaps,
                'contract_ok': not contract_gaps,
                'ok': not (duplicates or bad_edges or empty_relations)}
    finally:
        conn.close()


def export_graph(course: str | None = None) -> dict:
    conn = connect()
    try:
        nodes = [dict(row) for row in conn.execute('''SELECT kp.*,co.name AS course_name FROM kp
                                                      JOIN courses co ON co.id=kp.course_id
                                                     WHERE (? IS NULL OR co.name=?) ORDER BY kp.id''', [course, course]).fetchall()]
        ids = {row['id'] for row in nodes}
        edges = [dict(row) for row in conn.execute('SELECT * FROM kp_edges ORDER BY id').fetchall()
                 if row['from_kp'] in ids and row['to_kp'] in ids]
        return {'schema': 'cyberpal.graph.v1', 'course': course or '全部课程',
                'nodes': nodes, 'edges': edges}
    finally:
        conn.close()


def import_graph(payload: dict, *, course: str | None = None) -> dict:
    if not isinstance(payload, dict) or payload.get('schema') not in (None, 'cyberpal.graph.v1'):
        raise ValueError('图谱文件 schema 不受支持')
    nodes = payload.get('nodes') or []
    edges = payload.get('edges') or []
    if not isinstance(nodes, list) or not isinstance(edges, list) or len(nodes) > 10000 or len(edges) > 20000:
        raise ValueError('图谱节点或关系数量超出限制')
    conn = connect()
    try:
        name_by_id = {}
        created = 0
        for item in nodes:
            if not isinstance(item, dict) or not str(item.get('name') or '').strip():
                continue
            target_course = str(item.get('course_name') or course or payload.get('course') or '').strip()
            if not target_course or target_course == '全部课程':
                raise ValueError('每个图谱节点需要 course_name，或导入时指定 course')
            row = conn.execute('SELECT id FROM courses WHERE name=?', (target_course,)).fetchone()
            if not row:
                raise ValueError(f'课程不存在：{target_course}')
            existing = conn.execute('SELECT id FROM kp WHERE course_id=? AND name=?', (row['id'], item['name'].strip())).fetchone()
            if existing:
                kp_id = existing['id']
            else:
                cur = conn.execute('''INSERT INTO kp(course_id,name,band,chapter,gist,detail,trap,source,related,kp_type,freq,mastery)
                                      VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
                                    (row['id'], item['name'].strip(), str(item.get('band') or ''), str(item.get('chapter') or ''),
                                     str(item.get('gist') or ''), str(item.get('detail') or ''), str(item.get('trap') or ''),
                                     str(item.get('source') or ''), str(item.get('related') or ''), str(item.get('kp_type') or ''),
                                     str(item.get('freq') or ''), str(item.get('mastery') or '未读')))
                kp_id = cur.lastrowid
                created += 1
            if item.get('id') is not None:
                name_by_id[str(item['id'])] = kp_id
            if item.get('node_key'):
                name_by_id[str(item['node_key'])] = kp_id
        edge_count = 0
        for item in edges:
            if not isinstance(item, dict):
                continue
            a = name_by_id.get(str(item.get('from_kp')), item.get('from_kp'))
            b = name_by_id.get(str(item.get('to_kp')), item.get('to_kp'))
            if not isinstance(a, int) or not isinstance(b, int) or a == b:
                continue
            if not conn.execute('SELECT 1 FROM kp WHERE id=?', (a,)).fetchone() or not conn.execute('SELECT 1 FROM kp WHERE id=?', (b,)).fetchone():
                continue
            conn.execute('INSERT OR IGNORE INTO kp_edges(from_kp,to_kp,kind) VALUES(?,?,?)', (a, b, str(item.get('kind') or 'related')))
            edge_count += 1
        conn.commit()
        return {'ok': True, 'nodes_created': created, 'edges_added': edge_count}
    finally:
        conn.close()
