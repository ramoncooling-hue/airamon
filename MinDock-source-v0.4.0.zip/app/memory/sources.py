"""Index user-approved local course folders without changing the curated knowledge graph."""

from __future__ import annotations

import hashlib
import difflib
import json
import re
import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path
from shutil import copy2

from .db import connect
from . import domain_profiles
from .knowledge import normalize_candidate
from . import wiki

SUPPORTED = {'.txt', '.md', '.markdown', '.csv', '.pdf', '.docx', '.pptx',
             '.png', '.jpg', '.jpeg', '.webp', '.tif', '.tiff',
             '.wav', '.mp3', '.m4a', '.aac', '.flac', '.ogg'}
OCR_FORMATS = {'.png', '.jpg', '.jpeg', '.webp', '.tif', '.tiff', '.pdf'}
AUDIO_FORMATS = {'.wav', '.mp3', '.m4a', '.aac', '.flac', '.ogg'}
# Course textbooks are commonly large scanned PDFs; keep the limit explicit
# while allowing a single local textbook to enter the pipeline.
MAX_BYTES = 200 * 1024 * 1024


class ExtractionRequiredError(ValueError):
    """The file is stored, but a text/OCR extractor is required before indexing."""


def _tesseract_languages(executable: str | None) -> set[str]:
    if not executable:
        return set()
    try:
        output = subprocess.run([executable, '--list-langs'], capture_output=True,
                                text=True, check=False, timeout=8).stdout
    except (OSError, subprocess.SubprocessError):
        return set()
    return {line.strip() for line in output.splitlines()[1:] if line.strip()}


def extractor_status() -> dict:
    """Report local extractors so the UI can distinguish indexed from readable."""
    tesseract = shutil.which('tesseract')
    whisper = shutil.which('whisper') or shutil.which('whisper-cli')
    languages = _tesseract_languages(tesseract)
    return {
        'tesseract': bool(tesseract),
        'tesseract_languages': sorted(languages),
        'chinese_ocr': 'chi_sim' in languages or 'chi_tra' in languages,
        'whisper': bool(whisper),
    }


def _tesseract_text(image: Path) -> str:
    executable = shutil.which('tesseract')
    if not executable:
        raise ExtractionRequiredError('需要安装 tesseract 才能识别图片或扫描版 PDF')
    languages = _tesseract_languages(executable)
    if not ({'chi_sim', 'chi_tra'} & languages):
        raise ExtractionRequiredError('本机缺少中文 OCR 语言包（chi_sim/chi_tra），图片已保存但暂不能可靠提取中文')
    lang = 'chi_sim+eng' if 'chi_sim' in languages else 'chi_tra+eng'
    try:
        proc = subprocess.run([executable, str(image), 'stdout', '-l', lang, '--psm', '3'],
                              capture_output=True, text=True, check=False, timeout=120)
    except (OSError, subprocess.SubprocessError) as exc:
        raise ExtractionRequiredError(f'OCR 执行失败：{exc}') from exc
    if proc.returncode != 0 or not proc.stdout.strip():
        raise ExtractionRequiredError('OCR 没有识别出文字，请检查图片清晰度或安装中文语言包')
    return proc.stdout.strip()


def _audio_sidecar(path: Path) -> Path | None:
    for suffix in ('.txt', '.md'):
        candidate = path.with_suffix(suffix)
        if candidate.is_file():
            return candidate
    return None


def _transcription_text(path: Path) -> str:
    sidecar = _audio_sidecar(path)
    if sidecar:
        return sidecar.read_text(encoding='utf-8-sig', errors='replace').strip()
    whisper = shutil.which('whisper') or shutil.which('whisper-cli')
    if not whisper:
        raise ExtractionRequiredError(
            '音频已归档，但需要本机 Whisper/whisper-cli 转写；也可以把同名 .txt 或 .md 放在旁边后重新扫描'
        )
    with tempfile.TemporaryDirectory(prefix='cyberpal-whisper-') as tmp:
        try:
            proc = subprocess.run([whisper, str(path), '--output_dir', tmp, '--output_format', 'txt'],
                                  capture_output=True, text=True, check=False, timeout=900)
        except (OSError, subprocess.SubprocessError) as exc:
            raise ExtractionRequiredError(f'转写执行失败：{exc}') from exc
        output = Path(tmp) / f'{path.stem}.txt'
        if proc.returncode != 0 or not output.is_file():
            raise ExtractionRequiredError('转写失败，请检查 Whisper 模型或音频格式')
        return output.read_text(encoding='utf-8', errors='replace').strip()


def extract_structured(path: Path) -> tuple[str, list[str], list[dict]]:
    suffix = path.suffix.lower()
    headings: list[str] = []
    evidence: list[dict] = []
    if suffix in {'.txt', '.md', '.markdown', '.csv'}:
        text = path.read_text(encoding='utf-8-sig', errors='replace')
        if suffix in {'.md', '.markdown'}:
            headings = [m.group(1).strip() for m in re.finditer(r'^#{1,4}\s+(.+)$', text, re.M)]
        for number, line in enumerate(text.splitlines(), 1):
            if line.strip():
                evidence.append({'locator_type': 'line', 'locator_start': number,
                                 'locator_end': number, 'text': line.strip()})
    elif suffix == '.pdf':
        from pypdf import PdfReader
        pages = [page.extract_text() or '' for page in PdfReader(str(path)).pages]
        text = '\n'.join(pages)
        evidence = [{'locator_type': 'page', 'locator_start': number, 'locator_end': number,
                     'text': page.strip()} for number, page in enumerate(pages, 1) if page.strip()]
        chapter_headings = re.findall(r'^第[一二三四五六七八九十百零0-9]+章[^\n]{0,100}', text, re.M)
        headings.extend(item.strip() for item in chapter_headings if item.strip())
    elif suffix == '.docx':
        from docx import Document
        doc = Document(str(path))
        text = '\n'.join(p.text for p in doc.paragraphs)
        headings = [p.text.strip() for p in doc.paragraphs if p.style and p.style.name.startswith('Heading') and p.text.strip()]
        evidence = [{'locator_type': 'paragraph', 'locator_start': number, 'locator_end': number,
                     'text': paragraph.text.strip()} for number, paragraph in enumerate(doc.paragraphs, 1)
                    if paragraph.text.strip()]
        for table in doc.tables:
            text += '\n' + '\n'.join(' | '.join(c.text for c in row.cells) for row in table.rows)
        if len(re.sub(r'\s+', '', text)) < 2000 and shutil.which('pdftoppm') and shutil.which('tesseract'):
            with tempfile.TemporaryDirectory(prefix='cyberpal-ocr-') as tmp:
                prefix = str(Path(tmp) / 'page')
                proc = subprocess.run(['pdftoppm', '-r', '180', '-png', str(path), prefix],
                                      capture_output=True, text=True, check=False, timeout=300)
                if proc.returncode == 0:
                    ocr_pages = []
                    for image in sorted(Path(tmp).glob('page-*.png')):
                        try:
                            ocr_pages.append(_tesseract_text(image))
                        except ExtractionRequiredError:
                            continue
                    if ocr_pages:
                        pages = ocr_pages
                        text = '\n'.join(pages)
                        evidence = [{'locator_type': 'page_ocr', 'locator_start': number,
                                     'locator_end': number, 'text': page.strip()}
                                    for number, page in enumerate(pages, 1) if page.strip()]
    elif suffix in OCR_FORMATS - {'.pdf'}:
        text = _tesseract_text(path)
        evidence = [{'locator_type': 'ocr', 'locator_start': 1, 'locator_end': 1, 'text': text}]
    elif suffix in AUDIO_FORMATS:
        text = _transcription_text(path)
        evidence = [{'locator_type': 'transcript', 'locator_start': 1, 'locator_end': 1, 'text': text}]
    elif suffix == '.pptx':
        from pptx import Presentation
        slides = Presentation(str(path)).slides
        slide_text = ['\n'.join(shape.text for shape in slide.shapes if shape.has_text_frame).strip()
                      for slide in slides]
        text = '\n'.join(slide_text)
        evidence = [{'locator_type': 'slide', 'locator_start': number, 'locator_end': number,
                     'text': slide} for number, slide in enumerate(slide_text, 1) if slide]
        headings = [slide.shapes.title.text.strip() for slide in slides if slide.shapes.title and slide.shapes.title.text.strip()]
    else:
        raise ValueError('暂不支持该格式的文字抽取')
    cleaned = text.strip()
    if suffix == '.pdf' and len(re.sub(r'\s+', '', cleaned)) < 2000 and len(evidence) < 5:
        raise ExtractionRequiredError('PDF 可能是扫描件，当前需要 OCR 后才能建立知识索引')
    return cleaned, list(dict.fromkeys(headings))[:100], evidence


def extract(path: Path) -> tuple[str, list[str]]:
    """Backward-compatible text extraction API."""
    text, headings, _ = extract_structured(path)
    return text, headings


def chapter_sections(evidence: list[dict]) -> list[dict]:
    """Find real textbook chapter starts from page evidence, not table-of-contents rows."""
    starts: list[dict] = []
    pattern = re.compile(r'第\s*([0-9０-９]+)\s*章\s*(.{0,80}?)学习目的')
    for index, item in enumerate(evidence):
        compact = re.sub(r'\s+', '', str(item.get('text') or ''))
        match = pattern.search(compact)
        if not match:
            continue
        number = int(match.group(1).translate(str.maketrans('０１２３４５６７８９', '0123456789')))
        title = re.sub(r'[：:。．·…]+$', '', match.group(2)).strip()
        starts.append({'number': number, 'chapter': f'第{number}章',
                       'title': title, 'start_index': index})
    starts = [item for index, item in enumerate(starts)
              if index == 0 or item['number'] != starts[index - 1]['number']]
    sections = []
    for index, item in enumerate(starts):
        end = starts[index + 1]['start_index'] if index + 1 < len(starts) else len(evidence)
        rows = [dict(row) for row in evidence[item['start_index']:end]]
        chapter = f"{item['chapter']} {item['title']}".strip()
        sections.append({'chapter': chapter, 'number': item['number'],
                         'title': item['title'], 'evidence': rows,
                         'content': '\n'.join(row.get('text', '') for row in rows)})
    return sections


def _structural_heading(value: str) -> bool:
    compact = re.sub(r'\s+', '', str(value or ''))
    return bool(re.match(r'^第[0-9０-９一二三四五六七八九十百]+章', compact))


def _chunks(text: str, size: int = 1200) -> list[str]:
    # Character overlap preserves sentences crossing a boundary.
    return [text[i:i + size] for i in range(0, len(text), size - 150)][:500]


def _snapshot_paths(course_dir: Path, source_path: Path, digest: str) -> tuple[Path, Path]:
    version_dir = course_dir / 'source' / 'versions'
    version_dir.mkdir(parents=True, exist_ok=True)
    stem = re.sub(r'[^A-Za-z0-9_.\-\u4e00-\u9fff]+', '_', source_path.stem)[:100] or 'material'
    return version_dir / f'{stem}-{digest}{source_path.suffix.lower()}', version_dir / f'{stem}-{digest}.txt'


def _write_snapshot(course_dir: Path, source_path: Path, digest: str, content: str,
                    *, managed: bool) -> tuple[str, str] | None:
    # Only inbox material is copied into the course's managed history. An
    # externally linked folder remains user-owned and is never written into.
    if not managed:
        return None
    raw_path, text_path = _snapshot_paths(course_dir, source_path, digest)
    if not raw_path.exists():
        copy2(source_path, raw_path)
    if not text_path.exists():
        text_path.write_text(content, encoding='utf-8')
    return str(raw_path), str(text_path)


def scan_course(course: str, folders: list[Path], *, force_ocr: bool = False) -> dict:
    conn = connect()
    result = {'indexed': 0, 'unchanged': 0, 'failed': 0, 'stale': 0, 'files': []}
    try:
        row = conn.execute('SELECT id FROM courses WHERE name=?', (course,)).fetchone()
        if not row:
            raise ValueError('课程不存在')
        cid = row['id']
        for folder in folders:
            if not folder.is_dir():
                continue
            seen_paths: set[str] = set()
            for path in sorted(folder.rglob('*')):
                if not path.is_file() or path.is_symlink() or path.name.startswith('.'):
                    continue
                if path.suffix.lower() not in SUPPORTED:
                    continue
                path = path.resolve()
                seen_paths.add(str(path))
                item = {'path': str(path)}
                try:
                    if path.stat().st_size > MAX_BYTES:
                        raise ValueError('文件超过 200 MB')
                    digest = hashlib.sha256(path.read_bytes()).hexdigest()
                    old = conn.execute('SELECT * FROM source_files WHERE course_id=? AND path=?', (cid, str(path))).fetchone()
                    if old and old['sha256'] == digest and old['status'] == 'indexed':
                        # Backfill snapshots for files indexed before version
                        # history was introduced, without rebuilding chunks or candidates.
                        version = conn.execute(
                            'SELECT id FROM source_versions WHERE source_id=? AND sha256=?',
                            (old['id'], digest)
                        ).fetchone()
                        artifact = conn.execute(
                            'SELECT 1 FROM source_version_artifacts WHERE source_id=? AND sha256=?',
                            (old['id'], digest)
                        ).fetchone()
                        if not artifact and folder.name == 'inbox':
                            try:
                                content, _, _ = extract_structured(path)
                                snapshot = _write_snapshot(folder.parent, path, digest, content, managed=True)
                                if version and snapshot:
                                    with conn:
                                        conn.execute('''INSERT OR REPLACE INTO source_version_artifacts
                                            (source_version_id,source_id,sha256,original_path,raw_path,text_path)
                                            VALUES(?,?,?,?,?,?)''',
                                            (version['id'], old['id'], digest, str(path), snapshot[0], snapshot[1]))
                            except Exception:
                                pass
                        result['unchanged'] += 1
                        continue
                    if old and old['sha256'] == digest and old['status'] == 'ocr_required' and not force_ocr:
                        result['unchanged'] += 1
                        item.update(status='ocr_required', error=old['error'])
                        result['files'].append(item)
                        continue
                    content, headings, evidence = extract_structured(path)
                    if not content:
                        raise ValueError('未提取到文字；扫描版 PDF 需要 OCR')
                    course_dir = folder.parent if folder.name == 'inbox' else folder
                    if folder.name == 'inbox' and folder.parent.name:
                        source_dir = folder.parent / 'source'
                        source_dir.mkdir(parents=True, exist_ok=True)
                        copy2(path, source_dir / path.name)
                    with conn:
                        conn.execute('''INSERT INTO source_files(course_id,path,sha256,status,error,indexed_at)
                                        VALUES(?,?,?,'indexed','',?)
                                        ON CONFLICT(course_id,path) DO UPDATE SET sha256=excluded.sha256,
                                        status='indexed', error='', indexed_at=excluded.indexed_at''',
                                     (cid, str(path), digest, datetime.now().isoformat(timespec='seconds')))
                        sid = conn.execute('SELECT id FROM source_files WHERE course_id=? AND path=?', (cid, str(path))).fetchone()['id']
                        conn.execute('''INSERT OR IGNORE INTO source_versions(source_id,sha256,status)
                                        VALUES(?,?, 'indexed')''', (sid, digest))
                        version = conn.execute(
                            'SELECT id FROM source_versions WHERE source_id=? AND sha256=?', (sid, digest)
                        ).fetchone()
                        snapshot = _write_snapshot(course_dir, path, digest, content, managed=folder.name == 'inbox')
                        if snapshot and version:
                            conn.execute('''INSERT OR REPLACE INTO source_version_artifacts
                                (source_version_id,source_id,sha256,original_path,raw_path,text_path)
                                VALUES(?,?,?,?,?,?)''',
                                (version['id'], sid, digest, str(path), snapshot[0], snapshot[1]))
                        conn.execute('DELETE FROM source_chunks WHERE source_id=?', (sid,))
                        conn.execute('DELETE FROM evidence WHERE source_id=?', (sid,))
                        conn.execute('DELETE FROM graph_candidates WHERE source_id=?', (sid,))
                        conn.execute('DELETE FROM knowledge_candidates WHERE source_id=?', (sid,))
                        chunks = _chunks(content)
                        conn.executemany('INSERT INTO source_chunks(source_id,position,content) VALUES(?,?,?)',
                                         [(sid, i, chunk) for i, chunk in enumerate(chunks)])
                        conn.executemany('''INSERT OR IGNORE INTO evidence
                            (source_id,chunk_id,locator_type,locator_start,locator_end,content,content_hash)
                            VALUES(?,?,?,?,?,?,?)''', [
                                (sid, None, item['locator_type'], item['locator_start'], item['locator_end'],
                                 item['text'], hashlib.sha256(item['text'].encode('utf-8')).hexdigest())
                                for item in evidence if item['text']
                            ])
                        conn.executemany('''INSERT INTO knowledge_candidates
                            (source_id,schema_version,name,kp_type,chapter,gist,source,confidence,status)
                            VALUES(?,?,?,?,?,?,?,?,?)''', [
                                (sid, item['schema_version'], item['name'], item['kp_type'], item['chapter'],
                                 item['gist'], item['source'], item['confidence'], item['status'])
                                for heading in dict.fromkeys(headings) if heading
                                for item in [normalize_candidate({'name': heading, 'gist': heading}, source=str(path))]
                            ])
                    artifacts = wiki.write_artifacts(
                        course_dir=course_dir, course=course, source_path=str(path),
                        source_sha256=digest, content=content, headings=headings,
                        evidence=evidence, domain=domain_profiles.profile_for_course(course)['id'],
                    )
                    with conn:
                        conn.execute('''INSERT OR REPLACE INTO knowledge_notes
                            (source_id,path,source_sha256,status,updated_at)
                            VALUES(?,?,?,'draft',?)''',
                            (sid, artifacts['note'], digest, datetime.now().isoformat(timespec='seconds')))
                    item['status'] = 'indexed'
                    item['artifacts'] = artifacts
                    result['indexed'] += 1
                except Exception as exc:
                    with conn:
                        failure_status = 'ocr_required' if isinstance(exc, ExtractionRequiredError) else 'error'
                        existing = conn.execute('SELECT id FROM source_files WHERE course_id=? AND path=?',
                                                (cid, str(path))).fetchone()
                        if failure_status == 'ocr_required' and existing:
                            conn.execute('DELETE FROM source_chunks WHERE source_id=?', (existing['id'],))
                            conn.execute('DELETE FROM evidence WHERE source_id=?', (existing['id'],))
                        conn.execute(f'''INSERT INTO source_files(course_id,path,status,error) VALUES(?,?,'{failure_status}',?)
                                        ON CONFLICT(course_id,path) DO UPDATE SET status='error',error=excluded.error''',
                                     (cid, str(path), str(exc)[:300]))
                    if failure_status == 'ocr_required':
                        with conn:
                            conn.execute("UPDATE source_files SET status='ocr_required' WHERE course_id=? AND path=?",
                                         (cid, str(path)))
                    item.update(status=failure_status, error=str(exc)[:300])
                    result['failed'] += 1
                result['files'].append(item)
            if folder.name == 'inbox':
                prefix = str(folder.resolve()) + '/'
                stale_rows = conn.execute(
                    "SELECT id,path FROM source_files WHERE course_id=? AND path LIKE ? AND status='indexed'",
                    (cid, prefix + '%'),
                ).fetchall()
                for stale in stale_rows:
                    if stale['path'] not in seen_paths:
                        conn.execute("UPDATE source_files SET status='stale', error='原文件已移出课程投放目录' WHERE id=?",
                                     (stale['id'],))
                        result['stale'] += 1
                conn.commit()
        return result
    finally:
        conn.close()


def search(query: str, course: str | None = None, limit: int = 6,
           workspace: str | None = None) -> list[dict]:
    from .repo import keywords_of
    terms = [term for term in keywords_of(query) if len(term) >= 2][:8]
    if not terms:
        terms = [query.strip()]
    conn = connect()
    try:
        sql = '''SELECT sc.id, sc.content, sf.path, co.name AS course_name FROM source_chunks sc
                 JOIN source_files sf ON sf.id=sc.source_id JOIN courses co ON co.id=sf.course_id
                 WHERE sf.status='indexed' AND (''' + ' OR '.join('sc.content LIKE ?' for _ in terms) + ')'
        args: list = [f'%{term}%' for term in terms]
        if course:
            sql += ' AND co.name=?'
            args.append(course)
        if workspace:
            sql += " AND COALESCE((SELECT key FROM workspaces WHERE id=co.workspace_id),'studypal')=?"
            args.append(workspace)
        sql += ' ORDER BY sc.id DESC LIMIT ?'
        args.append(max(1, min(limit, 30)))
        return [{'id': r['id'], 'name': Path(r['path']).name, 'gist': r['content'][:1200],
                 'detail': '', 'source': r['path'], 'course_name': r['course_name'],
                 'chapter': '课程文件', 'mastery': '', 'kind': 'file'} for r in conn.execute(sql, args)]
    finally:
        conn.close()


def assist_wiki(course: str, source_path: str, *, tier: str = 'fast', chapter: str = '') -> dict:
    """Run the optional model pass for one indexed file and keep it review-only."""
    requested = Path(source_path).expanduser().resolve()
    conn = connect()
    try:
        source = conn.execute('''SELECT sf.*, co.name AS course_name
                                 FROM source_files sf JOIN courses co ON co.id=sf.course_id
                                 WHERE co.name=? AND sf.path=?''', (course, str(requested))).fetchone()
        if not source:
            raise ValueError('课程中没有找到这份已索引材料')
        if source['status'] != 'indexed':
            raise ValueError('只有已索引材料才能进行辅助拆录')
        path = Path(source['path'])
        if not path.is_file():
            raise ValueError('原材料文件已不存在，请先恢复文件并重新扫描')
        content, headings, evidence = extract_structured(path)
        selected_chapter = ''
        if chapter:
            section = next((item for item in chapter_sections(evidence)
                            if item['chapter'] == chapter or item['chapter'].startswith(chapter)), None)
            if not section:
                raise ValueError(f'材料中没有找到章节：{chapter}')
            content, evidence, selected_chapter = section['content'], section['evidence'], section['chapter']
            headings = [selected_chapter]
        result = wiki.assist_draft(
            course_dir=(path.parent.parent if path.parent.name == 'inbox' else path.parent),
            course=course, source_path=source['path'], source_sha256=source['sha256'],
            content=content, headings=headings, evidence=evidence, tier=tier,
            domain=domain_profiles.profile_for_course(course)['id'], chapter=selected_chapter,
            artifact_suffix=selected_chapter,
        )
        evidence_rows = [dict(item) for item in conn.execute(
            'SELECT id,locator_type,locator_start,locator_end,content FROM evidence WHERE source_id=? ORDER BY id',
            (source['id'],)
        ).fetchall()]
        if len(evidence_rows) < len(evidence):
            raise ValueError('数据库中的证据与当前文件不一致，请先重新扫描')
        with conn:
            for item in result['concepts']:
                candidate = normalize_candidate(item, source=source['path'])
                # Chapter-scoped extraction must inherit the canonical chapter
                # selected by the user; model prose cannot create a new tree.
                if selected_chapter:
                    candidate['chapter'] = selected_chapter
                candidate['status'] = 'pending'
                candidate['evidence_refs'] = list(item.get('evidence_refs', []))
                existing = conn.execute(
                    'SELECT id,status FROM knowledge_candidates WHERE source_id=? AND name=?',
                    (source['id'], candidate['name']),
                ).fetchone()
                if existing and existing['status'] != 'pending':
                    candidate_id = existing['id']
                elif existing:
                    conn.execute('''UPDATE knowledge_candidates SET schema_version=?,kp_type=?,chapter=?,
                                    gist=?,detail=?,trap=?,source=?,confidence=?,status='pending' WHERE id=?''',
                                 (candidate['schema_version'], candidate['kp_type'], candidate['chapter'],
                                  candidate['gist'], candidate['detail'], candidate['trap'], candidate['source'],
                                  candidate['confidence'], existing['id']))
                    candidate_id = existing['id']
                else:
                    cur = conn.execute('''INSERT INTO knowledge_candidates
                        (source_id,schema_version,name,kp_type,chapter,gist,detail,trap,source,confidence,status)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
                        (source['id'], candidate['schema_version'], candidate['name'], candidate['kp_type'],
                         candidate['chapter'], candidate['gist'], candidate['detail'], candidate['trap'],
                         candidate['source'], candidate['confidence'], 'pending'))
                    candidate_id = cur.lastrowid
                conn.execute('DELETE FROM knowledge_candidate_evidence WHERE candidate_id=?', (candidate_id,))
                refs = candidate.get('evidence_refs', [])
                evidence_ids = []
                for ref in refs:
                    if not isinstance(ref, int) or not 1 <= ref <= len(evidence):
                        continue
                    local = evidence[ref - 1]
                    match = next((item for item in evidence_rows
                                  if item['locator_type'] == local.get('locator_type')
                                  and item['locator_start'] == local.get('locator_start')
                                  and item['locator_end'] == local.get('locator_end')
                                  and item['content'] == local.get('text')), None)
                    if match:
                        evidence_ids.append(match['id'])
                conn.executemany(
                    'INSERT OR IGNORE INTO knowledge_candidate_evidence(candidate_id,evidence_id) VALUES(?,?)',
                    [(candidate_id, evidence_id) for evidence_id in dict.fromkeys(evidence_ids)]
                )
            conn.execute('''UPDATE knowledge_notes SET status='assisted_draft',updated_at=?
                            WHERE source_id=? AND source_sha256=?''',
                         (datetime.now().isoformat(timespec='seconds'), source['id'], source['sha256']))
        result['course'] = course
        result['source'] = source['path']
        result['source_id'] = source['id']
        return result
    finally:
        conn.close()


def delete_assisted_draft(course: str, source_path: str) -> dict:
    """Remove generated Wiki/dictionary drafts while preserving source evidence."""
    requested = Path(source_path).expanduser().resolve()
    conn = connect()
    deleted: list[str] = []
    try:
        source = conn.execute('''SELECT sf.*, co.name AS course_name
                                 FROM source_files sf JOIN courses co ON co.id=sf.course_id
                                 WHERE co.name=? AND sf.path=?''', (course, str(requested))).fetchone()
        if not source:
            raise ValueError('课程中没有找到这份已索引材料')
        course_dir = requested.parent.parent if requested.parent.name == 'inbox' else requested.parent
        note_rows = conn.execute('''SELECT path FROM knowledge_notes
                                    WHERE source_id=? AND source_sha256=?''',
                                 (source['id'], source['sha256'])).fetchall()
        candidates = [Path(row['path']).expanduser().resolve() for row in note_rows if row['path']]
        candidates.append(course_dir / 'dictionary' / f'{wiki._slug(str(requested))}.json')
        for target in dict.fromkeys(candidates):
            try:
                target.relative_to(course_dir)
            except ValueError as exc:
                raise ValueError('拆录产物路径不在课程目录内，已停止删除') from exc
            if target.is_file():
                target.unlink()
                deleted.append(str(target))
        with conn:
            conn.execute('''UPDATE knowledge_notes SET status='draft',updated_at=?
                            WHERE source_id=? AND source_sha256=?''',
                         (datetime.now().isoformat(timespec='seconds'), source['id'], source['sha256']))
        return {'ok': True, 'course': course, 'source': str(requested), 'deleted': deleted,
                'status': 'draft'}
    finally:
        conn.close()


def _version_artifact(conn, source_id: int, sha256: str):
    return conn.execute('''SELECT sva.* FROM source_version_artifacts sva
                           WHERE sva.source_id=? AND sva.sha256=?''', (source_id, sha256)).fetchone()


def diff_versions(course: str, source_path: str, from_sha: str, to_sha: str = 'latest') -> dict:
    requested = str(Path(source_path).expanduser().resolve())
    conn = connect()
    try:
        source = conn.execute('''SELECT sf.* FROM source_files sf JOIN courses co ON co.id=sf.course_id
                                 WHERE co.name=? AND sf.path=?''', (course, requested)).fetchone()
        if not source:
            raise ValueError('课程中没有找到这份材料')
        target_sha = source['sha256'] if to_sha == 'latest' else to_sha
        old = _version_artifact(conn, source['id'], from_sha)
        new = _version_artifact(conn, source['id'], target_sha)
        if not old or not new:
            raise ValueError('指定版本没有可用的本地快照')
        old_text = Path(old['text_path']).read_text(encoding='utf-8')
        new_text = Path(new['text_path']).read_text(encoding='utf-8')
        diff = '\n'.join(difflib.unified_diff(
            old_text.splitlines(), new_text.splitlines(),
            fromfile=f'{Path(requested).name}@{from_sha[:12]}',
            tofile=f'{Path(requested).name}@{target_sha[:12]}', lineterm=''
        ))
        return {'course': course, 'source': requested, 'from_sha': from_sha,
                'to_sha': target_sha, 'changed': old_text != new_text, 'diff': diff}
    finally:
        conn.close()


def restore_version(course: str, source_path: str, sha256: str) -> dict:
    requested = Path(source_path).expanduser().resolve()
    conn = connect()
    try:
        source = conn.execute('''SELECT sf.* FROM source_files sf JOIN courses co ON co.id=sf.course_id
                                 WHERE co.name=? AND sf.path=?''', (course, str(requested))).fetchone()
        if not source:
            raise ValueError('课程中没有找到这份材料')
        artifact = _version_artifact(conn, source['id'], sha256)
        if not artifact or not Path(artifact['raw_path']).is_file():
            raise ValueError('指定版本没有可恢复的原始文件快照')
        requested.parent.mkdir(parents=True, exist_ok=True)
        copy2(artifact['raw_path'], requested)
    finally:
        conn.close()
    result = scan_course(course, [requested.parent])
    item = next((row for row in result['files'] if row.get('path') == str(requested)), None)
    if not item or item.get('status') != 'indexed':
        raise ValueError('历史文件已恢复，但重新索引失败')
    return {'ok': True, 'course': course, 'source': str(requested), 'sha256': sha256,
            'status': item['status'], 'index': item}


def versions(course: str, source_path: str) -> list[dict]:
    requested = str(Path(source_path).expanduser().resolve())
    conn = connect()
    try:
        source = conn.execute('''SELECT sf.id FROM source_files sf JOIN courses co ON co.id=sf.course_id
                                 WHERE co.name=? AND sf.path=?''', (course, requested)).fetchone()
        if not source:
            raise ValueError('课程中没有找到这份材料')
        rows = conn.execute('''SELECT sv.sha256,sv.status,sv.captured_at,
                                      sva.raw_path,sva.text_path
                               FROM source_versions sv LEFT JOIN source_version_artifacts sva
                               ON sva.source_version_id=sv.id
                               WHERE sv.source_id=? ORDER BY sv.id DESC''', (source['id'],)).fetchall()
        return [{
            'sha256': row['sha256'], 'status': row['status'], 'captured_at': row['captured_at'],
            'has_raw': bool(row['raw_path'] and Path(row['raw_path']).is_file()),
            'has_text': bool(row['text_path'] and Path(row['text_path']).is_file()),
        } for row in rows]
    finally:
        conn.close()


def status(course: str) -> list[dict]:
    conn = connect()
    try:
        return [dict(r) for r in conn.execute('''SELECT sf.path,sf.sha256,sf.status,sf.error,sf.indexed_at,
                 (SELECT COUNT(*) FROM source_chunks WHERE source_id=sf.id) AS chunks
                 ,(SELECT COUNT(*) FROM source_versions WHERE source_id=sf.id) AS versions
                 FROM source_files sf JOIN courses co ON co.id=sf.course_id
                 WHERE co.name=? ORDER BY sf.path''', (course,))]
    finally:
        conn.close()


def inventory(course: str) -> list[dict]:
    """Return user-facing material and generated artifact paths for a course."""
    conn = connect()
    try:
        rows = conn.execute('''SELECT sf.id,sf.path,sf.sha256,sf.status,sf.error,sf.indexed_at,
                 (SELECT COUNT(*) FROM source_chunks WHERE source_id=sf.id) AS chunks,
                 (SELECT COUNT(*) FROM source_versions WHERE source_id=sf.id) AS versions,
                 (SELECT path FROM knowledge_notes WHERE source_id=sf.id ORDER BY id DESC LIMIT 1) AS note_path,
                 (SELECT status FROM knowledge_notes WHERE source_id=sf.id ORDER BY id DESC LIMIT 1) AS note_status
                 FROM source_files sf JOIN courses co ON co.id=sf.course_id
                 WHERE co.name=? ORDER BY sf.path''', (course,)).fetchall()
        result = []
        for row in rows:
            source_path = Path(row['path']).resolve()
            course_dir = source_path.parent.parent if source_path.parent.name == 'inbox' else source_path.parent
            source_copy = course_dir / 'source' / source_path.name
            note_path = Path(row['note_path']).resolve() if row['note_path'] else None
            dictionary_path = course_dir / 'dictionary' / f'{wiki._slug(str(source_path))}.json'
            artifact = conn.execute('''SELECT raw_path,text_path FROM source_version_artifacts
                                      WHERE source_id=? ORDER BY id DESC LIMIT 1''', (row['id'],)).fetchone()
            raw_path = Path(artifact['raw_path']).resolve() if artifact and artifact['raw_path'] else None
            text_path = Path(artifact['text_path']).resolve() if artifact and artifact['text_path'] else None

            def entry(label: str, path: Path | None) -> dict:
                return {'label': label, 'path': str(path) if path else '',
                        'exists': bool(path and path.is_file())}

            try:
                relative = str(source_path.relative_to(course_dir))
            except ValueError:
                relative = source_path.name
            result.append({
                'source_id': row['id'], 'name': source_path.name,
                'relative_path': relative, 'original_path': str(source_path),
                'status': row['status'], 'error': row['error'],
                'indexed_at': row['indexed_at'], 'chunks': row['chunks'],
                'versions': row['versions'], 'note_status': row['note_status'] or 'draft',
                'artifacts': {
                    'source_copy': entry('课程原材料副本', source_copy),
                    'raw_snapshot': entry('原始版本快照', raw_path),
                    'text_snapshot': entry('文本版本快照', text_path),
                    'note': entry('Wiki 拆录', note_path),
                    'dictionary': entry('结构化词典', dictionary_path),
                },
            })
        return result
    finally:
        conn.close()


def candidates(course: str) -> list[dict]:
    conn = connect()
    try:
        rows = [dict(r) for r in conn.execute('''SELECT kc.id,kc.name AS label,kc.status,kc.schema_version,
                 kc.kp_type,kc.chapter,kc.gist,kc.confidence,kc.source FROM knowledge_candidates kc
                 JOIN source_files sf ON sf.id=kc.source_id JOIN courses co ON co.id=sf.course_id
                 WHERE co.name=? ORDER BY kc.id''', (course,))]
        for row in rows:
            row['evidence_ids'] = [item['evidence_id'] for item in conn.execute(
                'SELECT evidence_id FROM knowledge_candidate_evidence WHERE candidate_id=? ORDER BY evidence_id',
                (row['id'],)
            )]
        return rows
    finally:
        conn.close()


def confirm_candidate(candidate_id: int) -> dict:
    conn = connect()
    try:
        row = conn.execute('''SELECT kc.id,kc.source_id,kc.name,kc.kp_type,kc.chapter,kc.gist,kc.detail,kc.trap,
             kc.source,kc.status,sf.course_id,co.name AS course_name FROM knowledge_candidates kc
             JOIN source_files sf ON sf.id=kc.source_id JOIN courses co ON co.id=sf.course_id
             WHERE kc.id=?''', (candidate_id,)).fetchone()
        if not row:
            raise ValueError('图谱候选不存在')
        if row['status'] != 'pending':
            raise ValueError('该图谱候选已经审核')
        existing = conn.execute(
            'SELECT id FROM kp WHERE course_id=? AND name=?', (row['course_id'], row['name'])
        ).fetchone()
        with conn:
            if existing:
                conn.execute("UPDATE knowledge_candidates SET status='duplicate' WHERE id=?", (candidate_id,))
                conn.execute('''INSERT INTO candidate_reviews(candidate_id,action,target_kp_id,note)
                                VALUES(?,?,?,?)''', (candidate_id, 'duplicate', existing['id'], '正式图谱已有同名节点'))
                return {'ok': True, 'status': 'duplicate', 'target_kp_id': existing['id'],
                        'label': row['name'], 'source': row['source']}
            cur = conn.execute('''INSERT INTO kp(course_id,name,source,chapter,gist,detail,trap,kp_type,band)
                                 VALUES(?,?,?,?,?,?,?,?, '文件')''',
                               (row['course_id'], row['name'], row['source'], row['chapter'], row['gist'],
                                row['detail'], row['trap'], row['kp_type']))
            target_id = cur.lastrowid
            domain = domain_profiles.profile_for_course(row['course_name'])['id']
            evidence_rows = conn.execute(
                '''SELECT e.id FROM evidence e JOIN knowledge_candidate_evidence kce ON kce.evidence_id=e.id
                   WHERE kce.candidate_id=? ORDER BY e.id LIMIT 20''', (candidate_id,)
            ).fetchall()
            if not evidence_rows:
                evidence_rows = conn.execute(
                    'SELECT id FROM evidence WHERE source_id=? ORDER BY id LIMIT 20', (row['source_id'],)
                ).fetchall()
            evidence_refs = [{'evidence_id': item['id']} for item in evidence_rows]
            conn.execute('''INSERT INTO knowledge_node_meta(kp_id,schema_version,domain,source_refs_json,status)
                            VALUES(?,?,?,?, 'confirmed')''',
                         (target_id, 'cyberpal.knowledge.v1', domain, json.dumps(evidence_refs, ensure_ascii=False)))
            conn.executemany('INSERT OR IGNORE INTO kp_evidence(kp_id,evidence_id,role) VALUES(?,?,?)',
                             [(target_id, item['id'], 'supports') for item in evidence_rows])
            conn.execute("UPDATE knowledge_candidates SET status='confirmed' WHERE id=?", (candidate_id,))
            conn.execute('''INSERT INTO candidate_reviews(candidate_id,action,target_kp_id)
                            VALUES(?,?,?)''', (candidate_id, 'confirmed', target_id))
        return {'ok': True, 'status': 'confirmed', 'target_kp_id': target_id,
                'label': row['name'], 'source': row['source']}
    finally:
        conn.close()


def review_candidate(candidate_id: int, action: str, target_kp_id: int | None = None,
                     note: str = '') -> dict:
    if action not in {'rejected', 'merged'}:
        raise ValueError('候选审核动作只能是 rejected 或 merged')
    conn = connect()
    try:
        row = conn.execute('SELECT id,status FROM knowledge_candidates WHERE id=?', (candidate_id,)).fetchone()
        if not row:
            raise ValueError('图谱候选不存在')
        if row['status'] != 'pending':
            raise ValueError('该图谱候选已经审核')
        if action == 'merged':
            if not target_kp_id or not conn.execute('SELECT 1 FROM kp WHERE id=?', (target_kp_id,)).fetchone():
                raise ValueError('合并候选必须指定有效的正式节点')
        with conn:
            conn.execute('UPDATE knowledge_candidates SET status=? WHERE id=?', (action, candidate_id))
            conn.execute('''INSERT INTO candidate_reviews(candidate_id,action,target_kp_id,note)
                            VALUES(?,?,?,?)''', (candidate_id, action, target_kp_id, note[:500]))
        return {'ok': True, 'status': action, 'target_kp_id': target_kp_id}
    finally:
        conn.close()
