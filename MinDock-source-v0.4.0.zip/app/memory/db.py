"""CyberPal · 记忆层连接与建库。

设计依据：docs/ARCHITECTURE.md
记忆层是整个系统的中心，这一层只负责「记忆怎么存、怎么取」，不含业务规则。
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from ..runtime import ROOT, data_dir

DATA_DIR = data_dir()
APP_DIR = DATA_DIR / "app"
SCHEMA_DIR = ROOT / "app" / "schema"
DB_PATH = APP_DIR / "banxue.db"


def connect() -> sqlite3.Connection:
    """打开记忆库。行用 sqlite3.Row，便于按字段名取。"""
    APP_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


def apply_schema() -> list[str]:
    """按文件名顺序执行 schema/*.sql（幂等，全部 CREATE IF NOT EXISTS）。"""
    conn = connect()
    applied: list[str] = []
    try:
        for sql_file in sorted(SCHEMA_DIR.glob("*.sql")):
            conn.executescript(sql_file.read_text(encoding="utf-8"))
            applied.append(sql_file.name)
        # SQLite has no portable IF NOT EXISTS form for ALTER TABLE. Keep
        # runtime migrations tiny and idempotent so older local databases can
        # be opened directly by a newly unpacked source bundle.
        workspace_columns = {
            'courses': {'workspace_id': 'INTEGER REFERENCES workspaces(id) ON DELETE SET NULL'},
            'events': {'workspace_id': 'INTEGER REFERENCES workspaces(id) ON DELETE SET NULL'},
            'conversations': {'workspace_id': 'INTEGER REFERENCES workspaces(id) ON DELETE SET NULL'},
        }
        for table, columns in workspace_columns.items():
            existing = {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
            for name, definition in columns.items():
                if name not in existing:
                    conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {definition}")
        item_columns = {row[1] for row in conn.execute('PRAGMA table_info(workspace_items)').fetchall()}
        if 'path' not in item_columns:
            conn.execute("ALTER TABLE workspace_items ADD COLUMN path TEXT NOT NULL DEFAULT ''")

        # Knowledge nodes keep the legacy display fields for compatibility,
        # while navigation uses stable textbook keys.
        kp_columns = {row[1] for row in conn.execute('PRAGMA table_info(kp)').fetchall()}
        for name, definition in (
            ('chapter_key', "TEXT NOT NULL DEFAULT ''"),
            ('section_key', "TEXT NOT NULL DEFAULT ''"),
        ):
            if name not in kp_columns:
                conn.execute(f"ALTER TABLE kp ADD COLUMN {name} {definition}")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_kp_chapter_key ON kp(course_id, chapter_key)")

        catalog_columns = {row[1] for row in conn.execute('PRAGMA table_info(chapter_catalog)').fetchall()}
        if 'catalog_version' not in catalog_columns:
            conn.execute("ALTER TABLE chapter_catalog ADD COLUMN catalog_version TEXT NOT NULL DEFAULT '1'")

        # Retire the old same-source cartesian candidate generator. It linked
        # every pair of concepts sharing a source, not a semantic relation.
        conn.execute("""UPDATE relation_candidates
                         SET status='rejected', reviewed_at=datetime('now','localtime')
                         WHERE status='pending'
                           AND reason='同一份材料中的已确认节点，待人工审核'""")

        conn.executemany(
            """INSERT OR IGNORE INTO workspaces
               (key,name,kind,domain,description,sort_order)
               VALUES (?,?,?,?,?,?)""",
            [
                ('studypal', 'StudyPal', 'study', 'mba', 'MBA 学习、课程材料、知识图谱与作业日历。', 0),
                ('lifepal', 'LifePal', 'life', '', '生活记录、个人计划与日常待办。', 1),
                ('workpal', 'WorkPal', 'work', '', '工作项目、会议记录与工作任务。', 2),
            ],
        )
        study_id = conn.execute("SELECT id FROM workspaces WHERE key='studypal'").fetchone()[0]
        conn.execute("UPDATE courses SET workspace_id=? WHERE workspace_id IS NULL", (study_id,))
        conn.execute("UPDATE events SET workspace_id=? WHERE workspace_id IS NULL", (study_id,))
        conn.execute("UPDATE conversations SET workspace_id=? WHERE workspace_id IS NULL", (study_id,))
        conn.execute("CREATE INDEX IF NOT EXISTS idx_courses_workspace ON courses(workspace_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_events_workspace ON events(workspace_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_conversations_workspace ON conversations(workspace_id)")

        event_columns = {
            row[1] for row in conn.execute("PRAGMA table_info(events)").fetchall()
        }
        for name, definition in (
            ('source', "TEXT NOT NULL DEFAULT 'local'"),
            ('source_uid', "TEXT NOT NULL DEFAULT ''"),
            ('source_updated_at', "TEXT NOT NULL DEFAULT ''"),
        ):
            if name not in event_columns:
                conn.execute(f"ALTER TABLE events ADD COLUMN {name} {definition}")
        conn.commit()
    finally:
        conn.close()
    return applied


def table_counts() -> dict[str, int]:
    """各表行数，用于验收核对。"""
    conn = connect()
    try:
        names = [
            r["name"]
            for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
            )
        ]
        return {n: conn.execute(f"SELECT COUNT(*) AS c FROM {n}").fetchone()["c"] for n in names}
    finally:
        conn.close()
