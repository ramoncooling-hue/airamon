"""SQLite FTS5 index with a deterministic LIKE fallback."""

from __future__ import annotations

import re

from .db import connect


# Event ownership comes from the event, including events without a course.
_JOINS = """LEFT JOIN courses co ON search_fts.kind != 'event'
                AND co.name=search_fts.course_name
            LEFT JOIN events ev ON search_fts.kind='event'
                AND ev.id=CAST(search_fts.ref_id AS INTEGER)
            LEFT JOIN workspaces ws ON ws.id=CASE WHEN search_fts.kind='event'
                THEN ev.workspace_id ELSE co.workspace_id END"""


def rebuild() -> int:
    conn = connect()
    try:
        conn.execute("DELETE FROM search_fts")
        conn.execute("""INSERT INTO search_fts(kind,ref_id,course_name,title,body)
                       SELECT 'kp',CAST(kp.id AS TEXT),co.name,kp.name,
                              coalesce(kp.gist,'')||' '||coalesce(kp.detail,'')||' '||
                              coalesce(kp.trap,'')||' '||coalesce(kp.related,'')
                       FROM kp JOIN courses co ON co.id=kp.course_id""")
        conn.execute("""INSERT INTO search_fts(kind,ref_id,course_name,title,body)
                       SELECT 'source_chunk',CAST(sc.id AS TEXT),co.name,sf.path,sc.content
                       FROM source_chunks sc JOIN source_files sf ON sf.id=sc.source_id
                       JOIN courses co ON co.id=sf.course_id WHERE sf.status='indexed'""")
        conn.execute("""INSERT INTO search_fts(kind,ref_id,course_name,title,body)
                       SELECT 'evidence',CAST(e.id AS TEXT),co.name,
                              sf.path||' '||coalesce(e.locator_type,''),e.content
                       FROM evidence e JOIN source_files sf ON sf.id=e.source_id
                       JOIN courses co ON co.id=sf.course_id WHERE sf.status='indexed'""")
        conn.execute("""INSERT INTO search_fts(kind,ref_id,course_name,title,body)
                       SELECT 'event',CAST(id AS TEXT),course_name,title,
                              coalesce(note,'')||' '||coalesce(category,'')||' '||coalesce(date,'')
                       FROM events""")
        conn.execute("""INSERT INTO search_fts(kind,ref_id,course_name,title,body)
                       SELECT 'notice',CAST(id AS TEXT),course_name,title,
                              coalesce(body,'')||' '||coalesce(source,'')||' '||coalesce(date,'')
                       FROM notices""")
        conn.execute("""INSERT INTO search_fts(kind,ref_id,course_name,title,body)
                       SELECT 'progress',CAST(p.id AS TEXT),co.name,p.topic,
                              coalesce(p.homework,'')||' '||coalesce(p.note,'')||' '||coalesce(p.due_at,'')
                       FROM progress p JOIN courses co ON co.id=p.course_id""")
        count = conn.execute("SELECT COUNT(*) FROM search_fts").fetchone()[0]
        conn.commit()
        return int(count)
    finally:
        conn.close()


def _terms(query: str) -> list[str]:
    text = ' '.join(str(query or '').split()).strip()
    words = re.findall(r'[A-Za-z0-9_]{2,}|[\u4e00-\u9fff]{2,}', text)
    if not words and text:
        words = [text[:80]]
    return list(dict.fromkeys(words[:12]))


def search(query: str, course: str | None = None, limit: int = 10,
           workspace: str | None = None) -> list[dict]:
    terms = _terms(query)
    if not terms:
        return []
    limit = max(1, min(int(limit), 50))
    match = ' OR '.join('"' + term.replace('"', ' ') + '"' for term in terms)
    conn = connect()
    try:
        sql = f"""SELECT search_fts.kind,search_fts.ref_id,search_fts.course_name,
                         search_fts.title,search_fts.body,bm25(search_fts) AS rank
                    FROM search_fts {_JOINS}
                   WHERE search_fts MATCH ?"""
        args: list = [match]
        if course:
            sql += ' AND search_fts.course_name=?'
            args.append(course)
        if workspace:
            sql += " AND COALESCE(ws.key,'studypal')=?"
            args.append(workspace)
        sql += ' ORDER BY rank LIMIT ?'
        args.append(limit)
        rows = [dict(row) for row in conn.execute(sql, args).fetchall()]
        if rows:
            conn.close()
            return rows
    except Exception:
        pass
    # FTS5 is optional in some embedded SQLite builds. Keep the app useful.
    clauses = ' OR '.join('(search_fts.title LIKE ? OR search_fts.body LIKE ?)' for _ in terms)
    args = []
    for term in terms:
        args.extend([f'%{term}%', f'%{term}%'])
    sql = f'''SELECT search_fts.kind,search_fts.ref_id,search_fts.course_name,
                     search_fts.title,search_fts.body,0 AS rank
                FROM search_fts {_JOINS}
               WHERE ({clauses})'''
    if course:
        sql += ' AND search_fts.course_name=?'
        args.append(course)
    if workspace:
        sql += " AND COALESCE(ws.key,'studypal')=?"
        args.append(workspace)
    sql += ' LIMIT ?'
    args.append(limit)
    try:
        return [dict(row) for row in conn.execute(sql, args).fetchall()]
    finally:
        conn.close()
