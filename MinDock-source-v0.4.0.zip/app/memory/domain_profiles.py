"""Loadable, portable domain profiles for the reusable knowledge graph."""

from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from typing import Any

from ..runtime import ROOT
from .knowledge import NODE_TYPES, RELATION_KINDS

PROFILE_DIR = ROOT / 'domains'
REQUIRED_KEYS = {'id', 'version', 'workspace', 'display_name', 'node_types',
                 'relation_kinds', 'required_fields', 'quality_rules', 'wiki_rules'}


def _validate(profile: dict[str, Any], path: Path) -> dict[str, Any]:
    missing = sorted(REQUIRED_KEYS - set(profile))
    if missing:
        raise ValueError(f'{path.name} 缺少领域档案字段：{", ".join(missing)}')
    if not re.fullmatch(r'[a-z][a-z0-9_-]{1,40}', str(profile['id'])):
        raise ValueError(f'{path.name} 的 id 不合法')
    for key, allowed in (('node_types', NODE_TYPES), ('relation_kinds', RELATION_KINDS)):
        values = profile[key]
        if not isinstance(values, list) or not values or not all(item in allowed for item in values):
            raise ValueError(f'{path.name} 的 {key} 含有未注册类型')
    if not isinstance(profile['required_fields'], list) or 'source_refs' not in profile['required_fields']:
        raise ValueError(f'{path.name} 必须要求 source_refs')
    if not isinstance(profile['quality_rules'], list) or not profile['quality_rules']:
        raise ValueError(f'{path.name} 必须至少有一条质量规则')
    if not isinstance(profile['wiki_rules'], dict):
        raise ValueError(f'{path.name} 的 wiki_rules 必须是对象')
    return profile


@lru_cache(maxsize=1)
def load_profiles() -> dict[str, dict[str, Any]]:
    profiles: dict[str, dict[str, Any]] = {}
    for path in sorted(PROFILE_DIR.glob('*.json')):
        payload = json.loads(path.read_text(encoding='utf-8'))
        profile = _validate(payload, path)
        profiles[profile['id']] = profile
    if not profiles:
        raise ValueError('没有可用的领域档案')
    return profiles


def profile_for_course(course: str = '', workspace: str = '') -> dict[str, Any]:
    value = f'{workspace} {course}'.strip()
    profiles = load_profiles()
    for profile in profiles.values():
        if workspace and workspace == profile['workspace']:
            return profile
        if any(str(pattern).casefold() in value.casefold() for pattern in profile.get('course_patterns', [])):
            return profile
    return profiles.get('mba') or next(iter(profiles.values()))


def public_profile(course: str = '', workspace: str = '') -> dict[str, Any]:
    profile = profile_for_course(course, workspace)
    return {
        'id': profile['id'], 'version': profile['version'],
        'workspace': profile['workspace'], 'display_name': profile['display_name'],
        'node_types': profile['node_types'], 'relation_kinds': profile['relation_kinds'],
        'required_fields': profile['required_fields'], 'quality_rules': profile['quality_rules'],
        'extraction_sections': profile.get('extraction_sections', []),
        'wiki_rules': profile['wiki_rules'],
    }


def clear_cache() -> None:
    load_profiles.cache_clear()
