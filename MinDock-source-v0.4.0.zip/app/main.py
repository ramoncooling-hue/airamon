"""CyberPal · 本机服务。

架构见 docs/ARCHITECTURE.md。
分层：交互层（web/）· 接口层（api/）· 智能体层（agent/）· 记忆层（memory/）

阶段 1 已就位：记忆地基 + 记忆读取/写回接口。
"""

from __future__ import annotations

from pathlib import Path
from threading import Event, Thread

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from .api.routes import router, scan_all_sources
from .memory.db import apply_schema, table_counts
from .memory import seed
from .memory import search_index

ROOT = Path(__file__).resolve().parents[1]
WEB_DIR = ROOT / "web"

app = FastAPI(title="CyberPal", docs_url=None, redoc_url=None)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)
_stop_scan = Event()


def _scan_loop() -> None:
    while not _stop_scan.is_set():
        try:
            scan_all_sources()
        except Exception:
            # A failed folder must not stop the local service; details remain on manual scan.
            pass
        _stop_scan.wait(60)


@app.on_event("startup")
def startup() -> None:
    """启动即确保记忆库结构就位（幂等）。"""
    apply_schema()
    if not table_counts().get('courses'):
        seed.refresh()
        # The public seed loader predates workspaces; the idempotent migration
        # also backfills its freshly inserted courses into StudyPal.
        apply_schema()
    try:
        search_index.rebuild()
    except Exception:
        # FTS5 is an optimization; LIKE search remains available.
        pass
    _stop_scan.clear()
    Thread(target=_scan_loop, daemon=True, name='studypal-file-scan').start()


@app.on_event('shutdown')
def shutdown() -> None:
    _stop_scan.set()


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "stage": 1, "tables": table_counts()}


app.mount("/", StaticFiles(directory=WEB_DIR, html=True), name="web")


@app.get("/")
def index() -> FileResponse:
    return FileResponse(WEB_DIR / "index.html")
