"""CyberPal · 模型层。

只有一个职责：把「一段消息 + 检索到的记忆」送进外部模型服务，拿回一段回答。
走 OpenAI 兼容的 /chat/completions（DeepSeek、通义、智谱、Kimi、OpenAI、本地
Ollama/vLLM 都是这套），所以不用绑任何 SDK —— 标准库 urllib 足够。

两个档位：
    fast       日常问答、检索作答
    reasoning  论文、论证、复杂分析

密钥只从这里读，不回传前端。
"""

from __future__ import annotations

import json
import ssl
import time
import urllib.error
import urllib.request
from typing import Any, Callable, Iterator

from ..settings import store as settings_store

# 本机调试时 http_proxy 会拦请求，模型服务必须绕开代理直连
_OPENER = urllib.request.build_opener(
    urllib.request.ProxyHandler({}),
    urllib.request.HTTPSHandler(context=ssl.create_default_context()),
)

TIMEOUT = 90


class LLMError(RuntimeError):
    """模型层错误，带可读的中文原因，前端能直接展示。"""


def _open_completion(request):
    # Retry transport/temporary upstream failures once; never retry bad credentials.
    for attempt in range(2):
        try:
            return _OPENER.open(request, timeout=TIMEOUT)
        except urllib.error.HTTPError as exc:
            if attempt or exc.code not in (429, 502, 503, 504):
                raise
            exc.close()
        except (urllib.error.URLError, TimeoutError):
            if attempt:
                raise
        time.sleep(0.5)


def tier_of(role: dict | None) -> str:
    """角色的模型档位。论文/论证类走 reasoning，其余走 fast。"""
    if role and role.get("model") in ("reasoning", "fast"):
        return role["model"]
    return "fast"


def _endpoint(base_url: str) -> str:
    base = (base_url or "").strip().rstrip("/")
    if not base:
        raise LLMError("接口地址为空")
    # 用户可能填的是 /v1 或完整路径，两种都接住
    if base.endswith("/chat/completions"):
        return base
    return base + "/chat/completions"


def available(tier: str = "fast") -> bool:
    cfg = settings_store.read_raw().get(tier, {})
    return bool(cfg.get("base_url") and cfg.get("model"))


def _payload(tier: str, messages: list[dict], temperature: float,
             stream: bool) -> tuple[str, dict, dict]:
    cfg = settings_store.read_raw().get(tier, {})
    if not (cfg.get("base_url") and cfg.get("model")):
        raise LLMError(f"「{tier}」档还没配好：请到 设置 → 模型与接口 填接口地址与模型名")

    url = _endpoint(cfg["base_url"])
    body = {
        "model": cfg["model"],
        "messages": messages,
        "temperature": temperature,
        "stream": stream,
    }
    headers = {
        "Content-Type": "application/json",
        "Accept": "text/event-stream" if stream else "application/json",
    }
    if cfg.get("api_key"):
        headers["Authorization"] = "Bearer " + cfg["api_key"]
    return url, body, headers


def _describe_http_error(e: urllib.error.HTTPError) -> str:
    """把上游的报错翻成人话，别让前端只说一句 500。"""
    detail = ""
    try:
        raw = e.read().decode("utf-8", "replace")
        data = json.loads(raw)
        detail = (data.get("error") or {}).get("message") or data.get("message") or raw
    except Exception:
        detail = ""
    hints = {
        401: "密钥无效或没填",
        403: "密钥没有这个模型的权限",
        404: "接口地址或模型名不对（检查是否漏了 /v1）",
        429: "被限流或余额不足",
    }
    hint = hints.get(e.code, "")
    return f"模型服务返回 {e.code}{'（' + hint + '）' if hint else ''}：{detail[:300]}"


def chat(tier: str, messages: list[dict], temperature: float = 0.3) -> str:
    """一次同步问答，返回回答正文。"""
    url, body, headers = _payload(tier, messages, temperature, stream=False)
    req = urllib.request.Request(
        url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST"
    )
    try:
        with _open_completion(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise LLMError(_describe_http_error(e)) from e
    except urllib.error.URLError as e:
        raise LLMError(
            f"连不上模型服务（{e.reason}）。检查接口地址、网络，或服务商是否要求代理。"
        ) from e
    except json.JSONDecodeError as e:
        raise LLMError("模型服务返回的不是 JSON，可能地址填错了") from e

    try:
        return data["choices"][0]["message"]["content"] or ""
    except (KeyError, IndexError) as e:
        raise LLMError(f"模型返回结构不认识：{json.dumps(data, ensure_ascii=False)[:200]}") from e


def chat_with_tools(
    tier: str,
    messages: list[dict],
    tools: list[dict],
    executor: Callable[[str, dict], dict],
    *,
    force_tool: bool = False,
    max_rounds: int = 3,
    temperature: float = 0.3,
    progress: Callable[[dict], None] | None = None,
    review_completion: Callable[[str], str] | None = None,
) -> tuple[str, list[dict], str]:
    """Run an OpenAI-compatible tool loop in the local host."""
    current = list(messages)
    web_results: list[dict] = []
    tool_error = ''
    for _ in range(max(1, max_rounds)):
        if progress:
            progress({'type': 'status', 'message': '正在理解问题与整理资料'})
        url, body, headers = _payload(tier, current, temperature, stream=bool(progress))
        body['tools'] = tools
        body['tool_choice'] = (
            {'type': 'function', 'function': {'name': tools[0]['function']['name']}}
            if force_tool and tools else 'auto'
        )
        req = urllib.request.Request(
            url, data=json.dumps(body).encode('utf-8'), headers=headers, method='POST'
        )
        try:
            with _open_completion(req) as resp:
                content_type = resp.headers.get('Content-Type', '') if hasattr(resp, 'headers') else ''
                if 'text/event-stream' in content_type:
                    data = _read_tool_stream(resp, progress)
                else:
                    data = json.loads(resp.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            raise LLMError(_describe_http_error(e)) from e
        except urllib.error.URLError as e:
            raise LLMError(f"连不上模型服务（{e.reason}）") from e
        except TimeoutError as e:
            raise LLMError('模型响应超时；已取得的来源保留在本轮下方，可重试') from e
        except json.JSONDecodeError as e:
            raise LLMError('模型服务返回的不是 JSON，可能地址填错了') from e

        try:
            message = data['choices'][0]['message']
        except (KeyError, IndexError) as e:
            raise LLMError(
                f"模型返回结构不认识：{json.dumps(data, ensure_ascii=False)[:300]}"
            ) from e
        calls = message.get('tool_calls') or []
        if not calls:
            feedback = review_completion(message.get('content') or '') if review_completion else ''
            if feedback:
                current.append({'role': 'assistant', 'content': message.get('content') or ''})
                current.append({'role': 'user', 'content': feedback})
                force_tool = False
                continue
            return message.get('content') or '', web_results, tool_error
        current.append({k: v for k, v in message.items() if k in {'role', 'content', 'tool_calls', 'reasoning_content'}})
        for call in calls:
            fn = call.get('function') or {}
            name = fn.get('name') or ''
            try:
                args = json.loads(fn.get('arguments') or '{}')
                result = executor(name, args)
            except Exception as exc:
                result = {'error': str(exc)}
            if name in {'web_search', 'web_open'} and isinstance(result, dict) and result.get('results'):
                web_results.extend(result['results'])
            if isinstance(result, dict) and result.get('error'):
                tool_error = str(result['error'])
            current.append({
                'role': 'tool',
                'tool_call_id': call.get('id', ''),
                'name': name,
                'content': json.dumps(result, ensure_ascii=False),
            })
        force_tool = False
    current.append({'role': 'user', 'content': '本轮工具预算已用完。请根据已经拿到的证据直接回答原问题；区分已核实与未核实，不承诺稍后执行。'})
    return chat(tier, current, temperature), web_results, tool_error


def _read_tool_stream(response, progress=None) -> dict:
    """Accumulate fragmented tool arguments while forwarding visible text deltas."""
    message = {'role': 'assistant', 'content': ''}
    calls = {}
    for raw in response:
        line = raw.decode('utf-8', 'replace').strip()
        if not line.startswith('data:'):
            continue
        data = line[5:].strip()
        if data == '[DONE]':
            break
        try:
            chunk = json.loads(data)
        except ValueError as exc:
            raise LLMError('模型流返回无效数据，请重试') from exc
        if chunk.get('error'):
            raise LLMError('模型流返回错误，请检查接口服务')
        for choice in chunk.get('choices', []):
            delta = choice.get('delta') or {}
            if delta.get('content'):
                message['content'] += delta['content']
                if progress:
                    progress({'type': 'delta', 'text': delta['content']})
            if delta.get('reasoning_content'):
                message['reasoning_content'] = message.get('reasoning_content', '') + delta['reasoning_content']
            for item in delta.get('tool_calls') or []:
                call = calls.setdefault(item.get('index', 0), {
                    'id': '', 'type': 'function', 'function': {'name': '', 'arguments': ''}
                })
                if item.get('id'):
                    call['id'] = item['id']
                for field in ('name', 'arguments'):
                    call['function'][field] += (item.get('function') or {}).get(field) or ''
    if calls:
        message['tool_calls'] = [calls[i] for i in sorted(calls)]
    return {'choices': [{'message': message}]}


def chat_stream(tier: str, messages: list[dict],
                temperature: float = 0.3) -> Iterator[str]:
    """流式问答，逐段吐字。上游不支持流式就退化成一次性返回。"""
    url, body, headers = _payload(tier, messages, temperature, stream=True)
    req = urllib.request.Request(
        url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST"
    )
    try:
        resp = _OPENER.open(req, timeout=TIMEOUT)
    except urllib.error.HTTPError as e:
        raise LLMError(_describe_http_error(e)) from e
    except urllib.error.URLError as e:
        raise LLMError(f"连不上模型服务（{e.reason}）") from e

    with resp:
        for raw in resp:
            line = raw.decode("utf-8", "replace").strip()
            if not line or not line.startswith("data:"):
                continue
            chunk = line[5:].strip()
            if chunk == "[DONE]":
                break
            try:
                obj = json.loads(chunk)
            except json.JSONDecodeError:
                continue
            try:
                piece = obj["choices"][0]["delta"].get("content")
            except (KeyError, IndexError):
                piece = None
            if piece:
                yield piece


def probe(tier: str = "fast") -> dict[str, Any]:
    """连通性自检：真发一次最小请求，让「配置不了模型」有个明确结论。"""
    cfg = settings_store.read_raw().get(tier, {})
    out: dict[str, Any] = {
        "tier": tier,
        "base_url": cfg.get("base_url", ""),
        "model": cfg.get("model", ""),
        "key_set": bool(cfg.get("api_key")),
    }
    try:
        reply = chat(tier, [{"role": "user", "content": "回复两个字：正常"}], 0)
        out.update(ok=True, reply=(reply or "")[:60])
    except LLMError as e:
        out.update(ok=False, error=str(e))
    return out
