"""CyberPal · 模型与接口配置。

存在 `data/app/settings.json`（不进版本库），只放本机。
密钥不回传前端明文——只回「有没有配」和尾号。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..memory.db import APP_DIR

SETTINGS_PATH = APP_DIR / "settings.json"

DEFAULTS: dict[str, Any] = {
    # 两个档位：fast 用于日常问答，reasoning 用于论文/论证
    "fast": {
        "provider": "",
        "base_url": "",
        "model": "",
        "api_key": "",
    },
    "reasoning": {
        "provider": "",
        "base_url": "",
        "model": "",
        "api_key": "",
    },
    # 检索与回答的行为开关
    "retrieval": {
        "top_k": 6,
        "require_citation": True,
        "vector": "off",          # off / local / remote
        "vector_model": "",
    },
    "web": {"provider": "bing_rss", "api_key": ""},
    "local_sources": {},
    # 外部通道
    "channels": {
        "tsinghua_imap_host": "mails.tsinghua.edu.cn",
        "tsinghua_imap_port": 993,
        "tsinghua_user": "",
        "tsinghua_password": "",
    },
}


def _merge(base: dict, over: dict) -> dict:
    """浅合并两层，保持 DEFAULTS 里新增的键不会因旧文件而缺失。"""
    out = json.loads(json.dumps(base))
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k].update(v)
        else:
            out[k] = v
    return out


def read_raw() -> dict:
    if not SETTINGS_PATH.exists():
        return json.loads(json.dumps(DEFAULTS))
    try:
        saved = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return json.loads(json.dumps(DEFAULTS))
    return _merge(DEFAULTS, saved)


def _mask(secret: str) -> str:
    """只露尾 4 位，前端不接触明文密钥。"""
    if not secret:
        return ""
    return "••••••" + secret[-4:] if len(secret) > 4 else "••••••"


def read_public() -> dict:
    """给前端看的版本：密钥脱敏，只说明配置状态。"""
    cfg = read_raw()
    out = json.loads(json.dumps(cfg))
    for tier in ("fast", "reasoning"):
        key = out.get(tier, {}).get("api_key", "")
        out[tier]["api_key_set"] = bool(key)
        out[tier]["api_key"] = _mask(key)
    ch = out.get("channels", {})
    pwd = ch.get("tsinghua_password", "")
    ch["password_set"] = bool(pwd)
    ch["tsinghua_password"] = _mask(pwd)
    for section in ("web",):
        key = out.get(section, {}).get("api_key", "")
        out[section]["api_key_set"] = bool(key)
        out[section]["api_key"] = _mask(key)
        provider = out[section].get("provider") or "bing_rss"
        out[section]["requires_key"] = provider in {"bocha", "tavily"}
        out[section]["ready"] = provider == "bing_rss" or bool(key)
        out[section]["status"] = "免 Key 可用" if provider == "bing_rss" else ("已配置" if key else "需要 API Key")
    return out


def write(patch: dict) -> dict:
    """接受局部更新。空字符串 = 清除该字段；不传 = 保持原样。"""
    current = read_raw()
    for section, values in (patch or {}).items():
        if section not in current:
            current[section] = values
            continue
        if isinstance(values, dict) and isinstance(current[section], dict):
            for k, v in values.items():
                # 前端回传的脱敏占位符不能覆盖真密钥
                if isinstance(v, str) and v.startswith("••••"):
                    continue
                current[section][k] = v
        else:
            current[section] = values
    APP_DIR.mkdir(parents=True, exist_ok=True)
    SETTINGS_PATH.write_text(
        json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return read_public()


def configured() -> dict:
    """哪些档位真的可用 —— 前端据此决定显不显示「已接入」标记。"""
    cfg = read_raw()
    return {
        tier: bool(cfg.get(tier, {}).get("base_url") and cfg.get(tier, {}).get("model"))
        for tier in ("fast", "reasoning")
    }
