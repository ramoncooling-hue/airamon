"""CyberPal · 接口层。

接口按「记忆的生命周期」组织，不按业务模块切：
    /api/*            记忆的读取与写回
    /api/settings/*   记忆的规则（角色、模型、通道）
    /api/agent/*      智能体问答（阶段 3、4）
    /api/intake/*     投放（阶段 5）
"""

from __future__ import annotations

import base64
import binascii
import os
import platform
import re
import sqlite3
import json
import queue
import subprocess
import threading
import io
import zipfile
import time
import html
from fastapi.responses import Response
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse
from pydantic import BaseModel

from ..agent import chat as agent_chat
from ..agent import llm
from ..agent import web_search
from ..hub import registry
from ..memory import chat_repo, db, repo, seed, sources, graph_tools, calendar_sync, search_index, platform_manual, domain_profiles
from ..settings import store as settings_store

router = APIRouter(prefix="/api")


# 原始材料先按课程落盘，后续抽取管线只需要消费这个稳定目录。
STUDYPAL_DIR = db.DATA_DIR / "StudyPal"


class IntakeIn(BaseModel):
    course: str
    workspace_key: str = 'studypal'
    filename: str
    content_base64: str
    mime: str = "application/octet-stream"


class RevealIn(BaseModel):
    path: str


class CourseIn(BaseModel):
    name: str
    workspace_key: str = 'studypal'
    teacher: str = ""
    nature: str = "选修课"
    credits: float = 0
    note: str = ""


class WebSaveIn(BaseModel):
    course: str
    workspace_key: str = 'studypal'
    title: str
    url: str
    snippet: str = ""
    body: str = ""
    retrieved_at: str = ""


class EventIn(BaseModel):
    record_id: str = ''
    course_id: int | None = None
    course_name: str = ''
    title: str
    category: str = 'personal'
    type_raw: str = ''
    date: str
    time_range: str = ''
    location: str = ''
    note: str = ''
    workspace_key: str = 'studypal'


class WorkspaceIn(BaseModel):
    key: str
    name: str
    kind: str = 'custom'
    domain: str = ''
    description: str = ''


class WorkspaceItemIn(BaseModel):
    workspace: str
    kind: str = 'note'
    title: str
    body: str = ''
    status: str = 'open'
    due_at: str = ''


def _safe_filename(value: str) -> str:
    name = Path(value or "材料").name.strip() or "材料"
    name = re.sub(r"[^\w.\-（）()\u4e00-\u9fff ]+", "_", name).strip(" .")
    return name[:180] or "材料"


def _workspace_folder(workspace_key: str = 'studypal') -> Path:
    return STUDYPAL_DIR if workspace_key == 'studypal' else db.DATA_DIR / _safe_filename(workspace_key)


def _course_workspace_key(course: str) -> str:
    conn = db.connect()
    try:
        row = conn.execute(
            """SELECT COALESCE(w.key,'studypal') AS workspace_key FROM courses c
               LEFT JOIN workspaces w ON w.id=c.workspace_id WHERE c.name=?""", (course,)
        ).fetchone()
    finally:
        conn.close()
    return row['workspace_key'] if row else 'studypal'


def _runtime_path(value: str) -> Path:
    """Resolve a user-visible path and keep OS actions inside the data root."""
    return Path(value or '').expanduser().resolve()


def _inside_runtime_root(path: Path) -> bool:
    root = db.DATA_DIR.expanduser().resolve()
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return path == root


@router.get('/runtime')
def runtime_info() -> dict:
    root = db.DATA_DIR.expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    return {
        'data_dir': str(root),
        'writable': os.access(root, os.W_OK),
        'platform': platform.system(),
        'mode': 'external' if os.environ.get('CYBERPAL_DATA_DIR', '').strip() else 'project-local',
    }


@router.post('/runtime/reveal')
def runtime_reveal(body: RevealIn) -> dict:
    path = _runtime_path(body.path)
    if not _inside_runtime_root(path):
        raise HTTPException(400, '只能打开当前应用数据目录内的文件或文件夹')
    if not path.exists():
        raise HTTPException(404, '文件或文件夹不存在')
    system = platform.system()
    try:
        if system == 'Darwin':
            subprocess.Popen(['open', '-R', str(path)])
        elif system == 'Windows':
            subprocess.Popen(['explorer', '/select,', str(path)])
        elif system == 'Linux':
            subprocess.Popen(['xdg-open', str(path if path.is_dir() else path.parent)])
        else:
            raise HTTPException(400, f'当前系统暂不支持打开目录：{system}')
    except OSError as exc:
        raise HTTPException(500, f'打开目录失败：{exc}') from exc
    return {'ok': True, 'path': str(path)}


@router.get('/workspaces')
def workspaces() -> list[dict]:
    return repo.list_workspaces()


@router.post('/workspaces')
def workspace_create(body: WorkspaceIn) -> dict:
    try:
        workspace = repo.create_workspace(body.key, body.name, kind=body.kind,
                                          domain=body.domain, description=body.description)
        _workspace_folder(workspace['key']).mkdir(parents=True, exist_ok=True)
        return {'ok': True, 'workspace': workspace}
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.get('/workspaces/{workspace_key}/items')
def workspace_items(workspace_key: str, kind: str | None = None) -> list[dict]:
    if not repo.get_workspace(workspace_key):
        raise HTTPException(404, '工作区不存在')
    return repo.list_workspace_items(workspace_key, kind)


@router.post('/workspaces/items')
def workspace_item_create(body: WorkspaceItemIn) -> dict:
    try:
        return repo.create_workspace_item(body.workspace, body.model_dump())
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.patch('/workspaces/items/{item_id}')
def workspace_item_update(item_id: int, body: dict) -> dict:
    try:
        return repo.update_workspace_item(item_id, body)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.delete('/workspaces/items/{item_id}')
def workspace_item_delete(item_id: int) -> dict:
    return {'ok': repo.delete_workspace_item(item_id)}


@router.post("/intake")
def intake(body: IntakeIn) -> dict:
    """将上传材料保存到 StudyPal/<课程>/inbox，等待后续抽取。"""
    course = (body.course or "").strip()
    allowed = {c["name"] for c in repo.list_courses()}
    if not course or course not in allowed:
        raise HTTPException(400, "请选择有效课程")

    encoded = body.content_base64 or ""
    if "," in encoded and encoded.startswith("data:"):
        encoded = encoded.split(",", 1)[1]
    try:
        content = base64.b64decode(encoded, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise HTTPException(400, "文件内容无效") from exc
    if not content:
        raise HTTPException(400, "不能归档空文件")
    if len(content) > sources.MAX_BYTES:
        raise HTTPException(413, "单个文件不能超过 200 MB")

    workspace_key = _course_workspace_key(course)
    folder = _workspace_folder(workspace_key) / _safe_filename(course) / "inbox"
    folder.mkdir(parents=True, exist_ok=True)
    filename = _safe_filename(body.filename)
    target = folder / filename
    if target.exists():
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        target = folder / f"{target.stem}-{stamp}{target.suffix}"
        index = 2
        while target.exists():
            target = folder / f"{Path(filename).stem}-{stamp}-{index}{Path(filename).suffix}"
            index += 1
    target.write_bytes(content)
    scanned = sources.scan_course(course, [folder])
    file_status = next((item for item in scanned['files'] if item['path'] == str(target.resolve())), None)
    course_dir = folder.parent
    return {
        "ok": True,
        "course": course,
        "filename": target.name,
        "bytes": len(content),
        "path": str(target.resolve()),
        "course_dir": str(course_dir.resolve()),
        "inbox_dir": str(folder.resolve()),
        "folder": f"{workspace_key}/{_safe_filename(course)}/inbox",
        "writable": os.access(folder, os.W_OK),
        "status": "已索引，可检索" if file_status and file_status['status'] == 'indexed' else
                  "已归档，等待 OCR/转写或格式支持" if target.suffix.lower() not in sources.SUPPORTED else
                  "已归档，抽取失败，请查看文件状态",
        "index": file_status,
    }


def scan_all_sources() -> dict:
    configured = settings_store.read_raw().get('local_sources', {})
    results = {}
    for course in repo.list_courses():
        name = course['name']
        extra = configured.get(name, []) if isinstance(configured, dict) else []
        if not isinstance(extra, list):
            extra = []
        folders = [_workspace_folder(course.get('workspace_key', 'studypal')) / _safe_filename(name) / 'inbox']
        folders += [Path(value).expanduser() for value in extra if isinstance(value, str)]
        results[name] = sources.scan_course(name, folders)
    return results


@router.post('/sources/scan')
def scan_sources(course: str | None = None) -> dict:
    if course:
        if course not in {c['name'] for c in repo.list_courses()}:
            raise HTTPException(404, '课程不存在')
        extra = settings_store.read_raw().get('local_sources', {}).get(course, [])
        if not isinstance(extra, list):
            extra = []
        folders = [_workspace_folder(_course_workspace_key(course)) / _safe_filename(course) / 'inbox'] + [Path(v).expanduser() for v in extra]
        return {course: sources.scan_course(course, folders)}
        return scan_all_sources()


@router.post('/sources/ocr')
def reprocess_ocr(course: str) -> dict:
    """Explicitly retry extraction for files previously deferred for OCR."""
    if course not in {c['name'] for c in repo.list_courses()}:
        raise HTTPException(404, '课程不存在')
    extra = settings_store.read_raw().get('local_sources', {}).get(course, [])
    if not isinstance(extra, list):
        extra = []
    folders = [_workspace_folder(_course_workspace_key(course)) / _safe_filename(course) / 'inbox'] + [Path(v).expanduser() for v in extra]
    return {course: sources.scan_course(course, folders, force_ocr=True)}


@router.get('/sources')
def source_status(course: str) -> dict:
    if course not in {c['name'] for c in repo.list_courses()}:
        raise HTTPException(404, '课程不存在')
    workspace_key = _course_workspace_key(course)
    course_dir = _workspace_folder(workspace_key) / _safe_filename(course)
    inbox_dir = course_dir / 'inbox'
    return {
        'data_dir': str(db.DATA_DIR.expanduser().resolve()),
        'course_dir': str(course_dir.resolve()),
        'inbox_dir': str(inbox_dir.resolve()),
        'writable': os.access(course_dir if course_dir.exists() else course_dir.parent, os.W_OK),
        'extractor': sources.extractor_status(),
        'files': sources.status(course),
        'materials': sources.inventory(course),
        'candidates': sources.candidates(course),
    }


@router.post('/sources/candidates/{candidate_id}/confirm')
def confirm_candidate(candidate_id: int) -> dict:
    try:
        return sources.confirm_candidate(candidate_id)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@router.post('/sources/candidates/{candidate_id}/review')
def review_candidate(candidate_id: int, body: dict) -> dict:
    try:
        return sources.review_candidate(candidate_id, body.get('action', ''), body.get('target_kp_id'), body.get('note', ''))
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


class FolderIn(BaseModel):
    course: str
    path: str


class WikiDraftIn(BaseModel):
    course: str
    path: str
    tier: str = 'fast'


class SourceDraftDeleteIn(BaseModel):
    course: str
    path: str


class SourceRestoreIn(BaseModel):
    course: str
    path: str
    sha256: str


class HubRestoreIn(BaseModel):
    revision_id: int


class HubSkillIn(BaseModel):
    key: str
    name: str
    version: str = '1.0.0'
    description: str = ''
    content: str
    enabled: bool = True


class HubImportIn(BaseModel):
    content_base64: str
    filename: str = 'hub.zip'


@router.post('/sources/folders')
def add_source_folder(body: FolderIn) -> dict:
    if body.course not in {c['name'] for c in repo.list_courses()}:
        raise HTTPException(404, '课程不存在')
    folder = Path(body.path).expanduser().resolve()
    if not folder.is_dir():
        raise HTTPException(400, '目录不存在或不是文件夹')
    current = settings_store.read_raw().get('local_sources', {})
    paths = current.setdefault(body.course, [])
    if str(folder) not in paths:
        paths.append(str(folder))
        settings_store.write({'local_sources': current})
    return {'course': body.course, 'folders': paths}


@router.post('/sources/wiki-draft')
def source_wiki_draft(body: WikiDraftIn) -> dict:
    if body.tier not in ('fast', 'reasoning'):
        raise HTTPException(400, '模型档位只能是 fast 或 reasoning')
    try:
        return sources.assist_wiki(body.course, body.path, tier=body.tier)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except Exception as exc:
        raise HTTPException(502, f'辅助拆录失败：{str(exc)[:300]}') from exc


@router.post('/sources/wiki-draft/delete')
def delete_source_draft(body: SourceDraftDeleteIn) -> dict:
    try:
        return sources.delete_assisted_draft(body.course, body.path)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.get('/sources/versions')
def source_versions(course: str, path: str) -> list[dict]:
    try:
        return sources.versions(course, path)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@router.get('/sources/diff')
def source_diff(course: str, path: str, from_sha: str, to_sha: str = 'latest') -> dict:
    try:
        return sources.diff_versions(course, path, from_sha, to_sha)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@router.post('/sources/restore')
def source_restore(body: SourceRestoreIn) -> dict:
    try:
        return sources.restore_version(body.course, body.path, body.sha256)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.post('/seed/refresh')
def refresh_seed() -> dict:
    try:
        return seed.refresh()
    except RuntimeError as exc:
        raise HTTPException(500, str(exc)) from exc


@router.get('/hub')
def hub_list() -> dict:
    try:
        return registry.list_registry()
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.post('/hub/agent', status_code=201)
def hub_agent_create(body: dict) -> dict:
    try:
        return registry.create_agent(body)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.post('/hub/skill', status_code=201)
def hub_skill_create(body: HubSkillIn) -> dict:
    try:
        return registry.create_skill(body.model_dump())
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.get('/hub/export')
def hub_export() -> Response:
    try:
        payload = registry.export_bundle()
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    return Response(content=payload, media_type='application/zip',
                    headers={'Content-Disposition': 'attachment; filename="cyberpal-hub.zip"'})


@router.post('/hub/import')
def hub_import(body: HubImportIn) -> dict:
    encoded = body.content_base64.split(',', 1)[-1]
    try:
        raw = base64.b64decode(encoded, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise HTTPException(400, 'Hub 压缩包内容无效') from exc
    try:
        return registry.import_bundle(raw)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.get('/hub/runs')
def hub_runs(limit: int = 50) -> list[dict]:
    conn = db.connect()
    try:
        return [dict(row) for row in conn.execute('SELECT * FROM hub_runs ORDER BY id DESC LIMIT ?', (max(1, min(limit, 200)),)).fetchall()]
    finally:
        conn.close()


@router.get('/hub/{kind}/{key}')
def hub_detail(kind: str, key: str) -> dict:
    try:
        return registry.get_detail(kind, key)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@router.get('/hub/{kind}/{key}/revisions')
def hub_revisions(kind: str, key: str) -> list[dict]:
    try:
        return registry.list_revisions(kind, key)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@router.post('/hub/revisions/restore')
def hub_restore(body: HubRestoreIn) -> dict:
    try:
        return registry.restore_revision(body.revision_id)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.patch('/hub/{kind}/{key}')
def hub_toggle(kind: str, key: str, body: dict) -> dict:
    try:
        if set(body) <= {'enabled'}:
            return registry.set_enabled(kind, key, bool(body.get('enabled', True)))
        return registry.update(kind, key, body)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


# ── 记忆：容器 ──────────────────────────────────────
@router.get("/courses")
def courses(workspace: str | None = None) -> list[dict]:
    return repo.list_courses(workspace)


@router.post("/courses")
def course_create(body: CourseIn) -> dict:
    """创建课程并同步建立该课程的本地材料入口。"""
    name = (body.name or "").strip()
    if not name:
        raise HTTPException(400, "课程名称不能为空")
    if _safe_filename(name) != name:
        raise HTTPException(400, "课程名称不能包含路径或文件名特殊字符")
    workspace_key = body.workspace_key or 'studypal'
    if not repo.get_workspace(workspace_key):
        raise HTTPException(400, '工作区不存在')
    folder = _workspace_folder(workspace_key) / name / "inbox"
    created_folder = not folder.exists()
    try:
        folder.mkdir(parents=True, exist_ok=True)
        course = repo.create_course(
            name,
            teacher=body.teacher,
            nature=body.nature,
            credits=body.credits,
            note=body.note,
            workspace=workspace_key,
        )
    except ValueError as exc:
        if created_folder:
            folder.rmdir()
            folder.parent.rmdir()
        raise HTTPException(400, str(exc)) from exc
    except (sqlite3.IntegrityError, TypeError) as exc:
        if created_folder:
            folder.rmdir()
            folder.parent.rmdir()
        raise HTTPException(400, "课程信息无效") from exc
    except OSError as exc:
        raise HTTPException(500, "无法创建课程存储目录，请检查本地写入权限") from exc
    return {
        "ok": True,
        "course": course,
        "folder": f"{workspace_key}/{_safe_filename(name)}/inbox",
    }


# ── 记忆：单元 ──────────────────────────────────────
@router.get("/kp")
def kp_list(course: str | None = None, band: str | None = None,
            mastery: str | None = None, freq: str | None = None) -> list[dict]:
    return repo.list_kp(course, band, mastery, freq)


@router.get("/kp/{kp_id}")
def kp_detail(kp_id: int) -> dict:
    d = repo.get_kp(kp_id)
    if not d:
        raise HTTPException(404, "知识点不存在")
    return d


class MasteryIn(BaseModel):
    mastery: str
    origin: str = "chat"
    confirmed: bool = True


@router.post("/kp/{kp_id}/mastery")
def kp_write_mastery(kp_id: int, body: MasteryIn) -> dict:
    """写回掌握度 —— 闭环的第 ⑥ 环。留痕由 repo 保证。"""
    if body.mastery not in ("熟练", "会用", "读过", "未读"):
        raise HTTPException(400, "掌握度只能是 熟练 / 会用 / 读过 / 未读")
    return repo.write_mastery(kp_id, body.mastery, body.origin, body.confirmed)


class KpPatch(BaseModel):
    name: str | None = None
    band: str | None = None
    chapter: str | None = None
    gist: str | None = None
    detail: str | None = None
    trap: str | None = None
    source: str | None = None
    related: str | None = None
    kp_type: str | None = None
    freq: str | None = None


class KpContractPatch(BaseModel):
    domain: str | None = None
    workspace: str = ''
    attributes: dict = {}
    aliases: list[str] = []
    evidence_ids: list[int] = []


@router.put("/kp/{kp_id}")
def kp_update(kp_id: int, body: KpPatch) -> dict:
    try:
        return repo.update_kp(
            kp_id,
            {key: value for key, value in body.model_dump().items() if value is not None},
            origin="manual-graph",
        )
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.put('/kp/{kp_id}/contract')
def kp_contract_update(kp_id: int, body: KpContractPatch) -> dict:
    try:
        return repo.update_node_contract(kp_id, body.model_dump())
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


class EdgeIn(BaseModel):
    from_kp: int
    to_kp: int
    kind: str = "related"


@router.post("/graph/edges")
def graph_edge_create(body: EdgeIn) -> dict:
    try:
        return repo.create_edge(body.from_kp, body.to_kp, body.kind)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.delete("/graph/edges/{edge_id}")
def graph_edge_delete(edge_id: int) -> dict:
    return repo.delete_edge(edge_id)


@router.get('/graph/candidates')
def graph_candidates(course: str | None = None, status: str = 'pending') -> list[dict]:
    return repo.list_relation_candidates(course, status)


@router.post('/graph/candidates/{candidate_id}/review')
def graph_candidate_review(candidate_id: int, body: dict) -> dict:
    try:
        return repo.review_relation_candidate(candidate_id, body.get('action', ''))
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.post('/graph/candidates/review-batch')
def graph_candidate_review_batch(body: dict) -> dict:
    action = body.get('action', 'confirmed')
    candidate_ids = body.get('candidate_ids', [])
    if not isinstance(candidate_ids, list) or not all(isinstance(item, int) for item in candidate_ids):
        raise HTTPException(400, 'candidate_ids 必须是整数数组')
    if len(candidate_ids) > 500:
        raise HTTPException(400, '单次最多处理 500 条关系候选')
    try:
        results = [repo.review_relation_candidate(item, action) for item in candidate_ids]
        return {'ok': True, 'action': action, 'count': len(results), 'results': results}
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


# ── 记忆：状态 ──────────────────────────────────────
@router.get("/mastery")
def mastery(course: str) -> dict:
    return repo.mastery_matrix(course)


# ── 记忆：结构 ──────────────────────────────────────
@router.get("/graph")
def graph(course: str) -> dict:
    return repo.graph_of(course)


@router.get('/graph/health')
def graph_health(course: str | None = None) -> dict:
    return graph_tools.health(course)


@router.get('/knowledge/profile')
def knowledge_profile(course: str = '', workspace: str = '') -> dict:
    return domain_profiles.public_profile(course, workspace)


@router.get('/graph/export')
def graph_export(course: str | None = None) -> dict:
    return graph_tools.export_graph(course)


@router.post('/graph/import')
def graph_import(body: dict, course: str | None = None) -> dict:
    try:
        return graph_tools.import_graph(body, course=course)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


# ── 记忆：时间投影 ──────────────────────────────────
@router.get("/events")
def events(course: str | None = None, workspace: str | None = None) -> list[dict]:
    return repo.list_events(course, workspace)


@router.get("/notices")
def notices(course: str | None = None, workspace: str | None = None) -> list[dict]:
    return repo.list_notices(course, workspace)


@router.post("/events")
def event_create(body: EventIn) -> dict:
    try:
        values = body.model_dump()
        workspace_key = values.pop('workspace_key', 'studypal') or 'studypal'
        workspace = repo.get_workspace(workspace_key)
        if not workspace:
            raise ValueError('工作区不存在')
        values['workspace_id'] = workspace['id']
        return repo.create_event(values)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.patch("/events/{event_id}")
def event_update(event_id: int, body: dict) -> dict:
    try:
        return repo.update_event(event_id, body)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.delete("/events/{event_id}")
def event_delete(event_id: int) -> dict:
    return {'ok': repo.delete_event(event_id)}


@router.get('/calendar/export.ics')
def calendar_export(course: str | None = None, workspace: str | None = None) -> Response:
    return Response(content=calendar_sync.export_ics(course, workspace), media_type='text/calendar; charset=utf-8',
                    headers={'Content-Disposition': 'attachment; filename="cyberpal-calendar.ics"'})


@router.post('/calendar/import.ics')
def calendar_import(body: dict) -> dict:
    text = str(body.get('content') or '')
    if not text:
        raise HTTPException(400, 'ICS 内容不能为空')
    try:
        return calendar_sync.import_ics(text, workspace=str(body.get('workspace') or 'studypal'))
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.get('/calendar/conflicts')
def calendar_conflicts(status: str = 'pending', workspace: str | None = None) -> list[dict]:
    return calendar_sync.conflicts(status, workspace)


@router.post('/calendar/conflicts/{conflict_id}/resolve')
def calendar_conflict_resolve(conflict_id: int, body: dict) -> dict:
    try:
        return calendar_sync.resolve_conflict(conflict_id, str(body.get('choice') or ''))
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.get("/agenda")
def agenda(q: str, course: str | None = None, workspace: str | None = None) -> dict:
    """Natural-language lookup over the structured calendar/task memory."""
    question = (q or "").strip()
    if not question:
        raise HTTPException(400, "查询内容不能为空")
    return repo.query_agenda(question, course, workspace)


# ── 记忆：关系（跨课桥接） ───────────────────────────
@router.get("/bridges")
def bridges(course: str | None = None) -> list[dict]:
    return repo.list_bridges(course)


# ── 写回留痕 ────────────────────────────────────────
@router.get("/revisions")
def revisions(limit: int = 30) -> list[dict]:
    return repo.list_revisions(limit)


# ── 设置：模型与接口 ────────────────────────────────
@router.get("/settings")
def settings_read() -> dict:
    """读配置。密钥脱敏，只回配置状态。"""
    return {
        "config": settings_store.read_public(),
        "configured": settings_store.configured(),
    }


@router.put("/settings")
def settings_write(patch: dict) -> dict:
    """局部更新配置。传空字符串 = 清除；不传 = 不动。"""
    return {
        "config": settings_store.write(patch),
        "configured": settings_store.configured(),
    }


@router.post("/settings/test")
def settings_test(body: dict | None = None) -> dict:
    """连通性自检：真发一次最小请求。
    「配不了模型」这种问题，要让界面给出确定结论，而不是靠猜。"""
    tier = (body or {}).get("tier", "fast")
    return llm.probe(tier)


# ── 检索即记忆 ──────────────────────────────────────
@router.get("/search")
def search(q: str, limit: int = 10, course: str | None = None, workspace: str | None = None) -> dict:
    """course 不传 = 跨全部课程（全局范围）；传了 = 只在那门课里找。"""
    hits = (repo.search(q, limit, course, workspace) + sources.search(q, course, limit, workspace))[:limit]
    return {"query": q, "scope": course or f"全部课程 · {workspace or '所有工作区'}", "count": len(hits), "hits": hits}


@router.get('/manual')
def platform_manual_search(q: str, limit: int = 8) -> dict:
    """查询随源码发布的平台使用手册，不混入课程知识图谱。"""
    hits = platform_manual.search(q, limit)
    return {'query': q, 'scope': 'CyberPal 平台', 'count': len(hits), 'hits': hits}


@router.get('/manual/open', response_class=HTMLResponse)
def platform_manual_open(path: str, line: int = 1) -> HTMLResponse:
    """Open one bundled manual at the cited Markdown line in a safe read-only view."""
    root = platform_manual.DOCS_DIR.resolve()
    requested = Path(path)
    if requested.is_absolute():
        raise HTTPException(400, '手册路径必须是相对路径')
    target = (root / requested).resolve()
    if not target.is_file() or target.suffix.lower() != '.md' or not target.is_relative_to(root):
        raise HTTPException(404, '手册章节不存在')
    try:
        lines = target.read_text(encoding='utf-8').splitlines()
    except OSError as exc:
        raise HTTPException(500, '手册读取失败') from exc
    focus = max(1, min(int(line or 1), max(len(lines), 1)))
    rows = []
    for number, value in enumerate(lines or [''], 1):
        cls = 'line focus' if number == focus else 'line'
        rows.append(
            f'<div id="line-{number}" class="{cls}"><span class="no">{number}</span>'
            f'<code>{html.escape(value)}</code></div>'
        )
    title = html.escape(target.stem)
    relative = html.escape(str(target.relative_to(root)))
    document = f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<title>{title} · MinDock 手册</title>
<style>
body{{margin:0;background:#f6f3fb;color:#25212d;font:15px/1.7 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}}
main{{max-width:1080px;margin:0 auto;padding:28px 34px 80px;background:#fff;min-height:100vh;box-sizing:border-box}}
h1{{font-size:22px;margin:0 0 4px;color:#4d2b78}} .meta{{color:#71677c;font-size:13px;margin-bottom:22px}}
.line{{display:grid;grid-template-columns:58px 1fr;border-left:3px solid transparent;min-height:26px}}
.line{{scroll-margin-top:18px}} .line.focus{{background:#f0e7fb;border-left-color:#7d4bb3;box-shadow:0 4px 14px rgba(83,45,125,.12)}}
.no{{color:#a69aae;text-align:right;padding:0 14px 0 0;user-select:none}} code{{white-space:pre-wrap;overflow-wrap:anywhere}}
a{{color:#6b3aa0}}
</style><main><h1>{title}</h1><div class="meta">MinDock 内置平台手册 · {relative} · 第 {focus} 行</div>
{''.join(rows)}<script>location.hash='line-{focus}';</script></main></html>'''
    return HTMLResponse(document)


@router.post('/search/rebuild')
def search_rebuild() -> dict:
    return {'ok': True, 'rows': search_index.rebuild()}


# ── 智能体问答（走真模型） ───────────────────────────
class AskIn(BaseModel):
    question: str
    course: str | None = None       # None = 全局
    role_key: str = "laoba"
    tier: str | None = None         # 不传则按角色推断
    limit: int = 6
    history: list[dict] = []        # [{role, content}]，只取最近几轮
    web_mode: str = 'auto'          # auto / on / off
    workspace: str = 'studypal'


@router.post("/agent/ask")
def agent_ask(body: AskIn) -> dict:
    return _agent_ask(body)


def _agent_ask(body: AskIn, progress=None) -> dict:
    """一次问答：先检索，再把记忆作为上下文交给模型，拿回带出处的回答。"""
    q = (body.question or "").strip()
    if not q:
        raise HTTPException(400, "问题不能为空")

    if body.web_mode not in ('auto', 'on', 'off'):
        raise HTTPException(400, 'web_mode 只能是 auto/on/off')
    hits = []
    agenda = None
    tier = body.tier or ('reasoning' if body.role_key == 'paper' else 'fast')
    workspace = repo.get_workspace(body.workspace or 'studypal')
    if not workspace:
        raise HTTPException(400, '工作区不存在')
    scope_label = body.course or f"全部课程 · {workspace['name']}"
    web_results = []
    web_error = ''
    started = time.monotonic()
    started_at = datetime.now().isoformat(timespec='seconds')
    conn = db.connect()
    run_id = conn.execute('INSERT INTO hub_runs(agent_key,started_at,status) VALUES(?,?,?)',
                          (body.role_key, started_at, 'running')).lastrowid
    conn.commit()
    conn.close()
    try:
        out = agent_chat.answer(
            q, hits, body.role_key, tier, scope_label, body.history, agenda=agenda,
            web_results=web_results, web_mode=body.web_mode, progress=progress,
            workspace=body.workspace or 'studypal'
        )
    except Exception as exc:
        conn = db.connect()
        try:
            conn.execute("UPDATE hub_runs SET status='error',finished_at=?,duration_ms=?,error=? WHERE id=?",
                         (datetime.now().isoformat(timespec='seconds'), int((time.monotonic()-started)*1000), str(exc)[:500], run_id))
            conn.commit()
        finally:
            conn.close()
        raise
    conn = db.connect()
    try:
        tool_names = [str(item.get('tool')) for item in out.get('trace', []) if item.get('type') == 'tool']
        conn.execute("""UPDATE hub_runs SET status=?,finished_at=?,duration_ms=?,tool_summary=?,error=? WHERE id=?""",
                     ('success' if out.get('ok') else 'error', datetime.now().isoformat(timespec='seconds'),
                      int((time.monotonic()-started)*1000), ','.join(tool_names), str(out.get('error') or '')[:500], run_id))
        conn.commit()
    finally:
        conn.close()
    web_results = out.get('web_results', web_results)
    web_error = out.get('web_error', web_error)
    hits = out.get('hits', [])
    agenda = out.get('agenda')

    return {
        "question": q,
        "scope": scope_label,
        "role_key": body.role_key,
        "tier": tier,
        "engine": "model" if out["ok"] else "local",
        "error": out["error"],
        "text": out["text"],
        "hits": hits,
        "count": len(hits),
        "agenda": agenda,
        "manual_results": out.get('manual_results', []),
        "model_ready": llm.available(tier),
        "web_results": web_results,
        "web_error": web_error,
        "web_query": out.get("web_query", ""),
        "trace": out.get('trace', []),
    }


@router.post('/agent/ask/stream')
def agent_ask_stream(body: AskIn):
    if not body.question.strip() or body.web_mode not in ('auto', 'on', 'off'):
        raise HTTPException(400, '问题为空或联网模式无效')
    events = queue.Queue()

    def worker():
        try:
            events.put({'type': 'result', 'data': _agent_ask(body, progress=events.put)})
        except Exception:
            events.put({'type': 'error', 'message': '问答执行失败，请重试并检查本地服务日志'})
        finally:
            events.put(None)

    def stream():
        threading.Thread(target=worker, daemon=True).start()
        while True:
            try:
                item = events.get(timeout=10)
            except queue.Empty:
                yield ': heartbeat\n\n'
                continue
            if item is None:
                break
            yield 'data: ' + json.dumps(item, ensure_ascii=False) + '\n\n'

    return StreamingResponse(stream(), media_type='text/event-stream', headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'})


@router.post("/web/save")
def web_save(body: WebSaveIn) -> dict:
    """保存一条联网资料到指定课程的 inbox，并立即建立本地索引。"""
    course = (body.course or "").strip()
    allowed = {c["name"] for c in repo.list_courses()}
    if not course or course not in allowed:
        raise HTTPException(400, "请选择有效课程")
    title = " ".join((body.title or "网页资料").split()).strip() or "网页资料"
    url = (body.url or "").strip()
    if not url:
        raise HTTPException(400, "网页地址不能为空")
    try:
        web_search._public_url(url)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc

    content = (body.body or "").strip()
    fetch_note = ""
    if not content:
        try:
            page = web_search.open_page(url)
            content = (page.get("body") or page.get("snippet") or "").strip()
            title = " ".join((page.get("title") or title).split()).strip() or title
        except Exception as exc:
            fetch_note = f"网页正文暂未抓取：{exc}"
    if not content:
        content = (body.snippet or "").strip()
    if not content:
        raise HTTPException(502, "网页没有可保存的摘要或正文")

    workspace_key = _course_workspace_key(course)
    folder = _workspace_folder(workspace_key) / _safe_filename(course) / "inbox"
    folder.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = _safe_filename(f"网页资料-{title}")[:150] + f"-{stamp}.md"
    target = folder / filename
    markdown = (
        f"# {title}\n\n"
        f"- 来源：{url}\n"
        f"- 检索时间：{body.retrieved_at or datetime.now().isoformat(timespec='seconds')}\n"
        f"- 保存时间：{datetime.now().isoformat(timespec='seconds')}\n\n"
        f"## 摘要\n\n{body.snippet.strip() or content[:1500]}\n\n"
        f"## 正文摘录\n\n{content[:40000]}\n"
    )
    if fetch_note:
        markdown += f"\n> {fetch_note}\n"
    target.write_text(markdown, encoding="utf-8")
    scanned = sources.scan_course(course, [folder])
    file_status = next(
        (item for item in scanned["files"] if item["path"] == str(target.resolve())), None
    )
    return {
        "ok": True,
        "course": course,
        "filename": target.name,
        "folder": f"{workspace_key}/{_safe_filename(course)}/inbox",
        "status": "已保存并建立本地索引" if file_status and file_status.get("status") == "indexed" else "已保存，待索引",
        "index": file_status,
    }


@router.get("/agent/status")
def agent_status() -> dict:
    """模型层当前能不能用，以及库里存了多少对话。"""
    return {
        "tiers": {
            t: {"ready": llm.available(t), "configured": settings_store.configured().get(t, False)}
            for t in ("fast", "reasoning")
        },
        "chat": chat_repo.stats(),
    }


# ── 会话（对话落库，不再刷新即丢） ────────────────────
class ConvIn(BaseModel):
    title: str = "新对话"
    scope: str = "*"
    role_key: str = "laoba"
    tier: str = "fast"
    workspace: str = 'studypal'


@router.get("/conversations")
def conversations(limit: int = 50, workspace: str | None = None) -> list[dict]:
    return chat_repo.list_conversations(limit, workspace)


@router.post("/conversations")
def conversation_create(body: ConvIn) -> dict:
    try:
        return chat_repo.create_conversation(body.title, body.scope, body.role_key, body.tier, body.workspace)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.get("/conversations/{conv_id}")
def conversation_get(conv_id: int) -> dict:
    d = chat_repo.get_conversation(conv_id)
    if not d:
        raise HTTPException(404, "会话不存在")
    return d


@router.patch("/conversations/{conv_id}")
def conversation_patch(conv_id: int, body: dict) -> dict:
    d = chat_repo.update_conversation(conv_id, body)
    if not d:
        raise HTTPException(404, "会话不存在")
    return d


@router.delete("/conversations/{conv_id}")
def conversation_delete(conv_id: int) -> dict:
    return {"deleted": chat_repo.delete_conversation(conv_id)}


class MsgIn(BaseModel):
    role: str                       # user / assistant
    content: str
    role_name: str = ""
    scope_label: str = ""
    steps: list = []
    citations: list = []
    writeback: list = []
    engine: str = "local"
    error: str = ""
    metadata: dict = {}


@router.post("/conversations/{conv_id}/messages")
def message_add(conv_id: int, body: MsgIn) -> dict:
    if not chat_repo.get_conversation(conv_id):
        raise HTTPException(404, "会话不存在")
    msg = chat_repo.add_message(
        conv_id, body.role, body.content,
        role_name=body.role_name, scope_label=body.scope_label,
        steps=body.steps, citations=body.citations, writeback=body.writeback,
        engine=body.engine, error=body.error, metadata=body.metadata,
    )
    if body.role == "user":
        chat_repo.autotitle(conv_id, body.content)
    return msg
