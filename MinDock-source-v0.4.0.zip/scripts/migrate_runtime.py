#!/usr/bin/env python3
"""Migrate a CyberPal runtime data directory without overwriting the target."""

from __future__ import annotations

import argparse
import shutil
import sqlite3
from pathlib import Path

from app.runtime import DEFAULT_DATA_DIR


def migrate(source: Path, target: Path, *, merge: bool = False) -> dict[str, str]:
    source = source.expanduser().resolve()
    target = target.expanduser().resolve()
    if target == source or target.is_relative_to(source):
        raise ValueError('目标不能位于源数据目录内')
    if not source.is_dir():
        raise ValueError(f'源数据目录不存在：{source}')
    if target.exists() and any(target.iterdir()) and not merge:
        raise ValueError(f'目标目录非空，已拒绝覆盖：{target}')
    target.mkdir(parents=True, exist_ok=True)

    source_db = source / 'app' / 'banxue.db'
    target_app = target / 'app'
    target_app.mkdir(parents=True, exist_ok=True)
    target_db = target_app / 'banxue.db'
    if source_db.exists():
        source_conn = sqlite3.connect(source_db)
        target_conn = sqlite3.connect(target_db)
        try:
            source_conn.backup(target_conn)
        finally:
            target_conn.close()
            source_conn.close()

    settings = source / 'app' / 'settings.json'
    if settings.exists():
        shutil.copy2(settings, target_app / 'settings.json')
    for folder in source.iterdir():
        if folder.is_dir() and folder.name != 'app':
            shutil.copytree(folder, target / folder.name, dirs_exist_ok=True)
    hub = source / 'app' / 'hub'
    if hub.exists():
        shutil.copytree(hub, target_app / 'hub', dirs_exist_ok=True)
    if target_db.exists():
        with sqlite3.connect(target_db) as conn:
            exists = conn.execute("SELECT 1 FROM sqlite_master WHERE name='workspace_items'").fetchone()
            if exists:
                for item_id, old in conn.execute('SELECT id,path FROM workspace_items').fetchall():
                    if old and Path(old).is_relative_to(source):
                        conn.execute('UPDATE workspace_items SET path=? WHERE id=?',
                                     (str(target / Path(old).relative_to(source)), item_id))
    return {'source': str(source), 'target': str(target), 'database': str(target_db)}


def main() -> None:
    parser = argparse.ArgumentParser(description='迁移 CyberPal 本地运行数据')
    parser.add_argument('--from', dest='source', type=Path, default=DEFAULT_DATA_DIR)
    parser.add_argument('--to', dest='target', type=Path, required=True)
    parser.add_argument('--merge', action='store_true', help='允许合并到已有目标目录，不删除目标文件')
    args = parser.parse_args()
    print(migrate(args.source, args.target, merge=args.merge))


if __name__ == '__main__':
    main()
