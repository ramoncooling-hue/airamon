#!/usr/bin/env python3
"""Create a portable UTF-8 source archive from a staged share directory."""

from __future__ import annotations

import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


def excluded(relative: Path) -> bool:
    parts = relative.parts
    return (
        "__pycache__" in parts
        or relative.as_posix() == "docs/MinDock-品牌手册.png"
        or parts[:2] == ("docs", "superpowers")
        or parts[0] in {"output", ".venv", "data"}
    )


def main() -> None:
    root = Path(sys.argv[1]).resolve()
    archive = Path(sys.argv[2]).resolve()
    with ZipFile(archive, "w", compression=ZIP_DEFLATED, compresslevel=6) as output:
        for path in sorted(root.rglob("*")):
            if path.is_file():
                relative = path.relative_to(root)
                if not excluded(relative):
                    output.write(path, relative.as_posix())


if __name__ == "__main__":
    main()
