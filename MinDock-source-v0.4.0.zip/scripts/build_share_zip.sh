#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VERSION="$(tr -d '[:space:]' < "$ROOT/VERSION")"
OUT_DIR="${1:-$ROOT/output/share}"
OUT_DIR="$(mkdir -p "$OUT_DIR" && cd "$OUT_DIR" && pwd)"
ARCHIVE="$OUT_DIR/CyberPal-source-v${VERSION}.zip"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT

rm -f "$ARCHIVE"
for item in app web skills agents scripts tests docs domains; do
  cp -R "$ROOT/$item" "$STAGE/$item"
done
cp "$ROOT/README.md" "$ROOT/LICENSE" "$ROOT/VERSION" "$ROOT/CHANGELOG.md" "$ROOT/requirements.txt" "$ROOT/.gitignore" "$ROOT/启动伴学.command" "$ROOT/start_cyberpal.bat" "$ROOT/DEMO-页面索引.md" "$STAGE/"
mkdir -p "$STAGE/seed"
cp "$ROOT"/seed/public/* "$STAGE/seed/"
cd "$STAGE"
python3 "$ROOT/scripts/zip_share_utf8.py" "$STAGE" "$ARCHIVE"

echo "$ARCHIVE"
