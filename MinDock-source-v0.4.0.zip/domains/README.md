# CyberPal 领域档案

领域档案是知识图谱的可替换配置，不是另一套代码。平台核心合同固定来源、证据、节点、关系、候选、审核、修订和版本；这里定义不同场景的节点类型、关系范围、必填字段、质量规则和 Wiki 段落。

- `mba.json`：StudyPal 当前 MBA 学习场景。
- `history.json`：HistoryPal 历史资料场景。
- `ecommerce.json`：电商经营场景示例。

新增领域时复制一份 JSON，先通过 `GET /api/knowledge/profile` 的校验，再把课程名称或工作区映射到该档案。不要在代码里新增领域分支。
