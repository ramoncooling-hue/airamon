import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from app.memory import db
from scripts.migrate_runtime import migrate


class RuntimeMigrationTests(unittest.TestCase):
    def test_migrate_copies_database_settings_and_materials(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / 'source'
            target = root / 'target'
            (source / 'app').mkdir(parents=True)
            (source / 'StudyPal' / '会计学').mkdir(parents=True)
            (source / 'app' / 'settings.json').write_text(json.dumps({'fast': {'model': 'local'}}), encoding='utf-8')
            (source / 'StudyPal' / '会计学' / 'notes.md').write_text('材料', encoding='utf-8')
            (source / 'lifepal' / 'notes').mkdir(parents=True)
            (source / 'lifepal' / 'notes' / 'record.md').write_text('生活记录', encoding='utf-8')
            with patch.object(db, 'APP_DIR', source / 'app'), patch.object(db, 'DB_PATH', source / 'app' / 'banxue.db'):
                db.apply_schema()
                conn = db.connect()
                conn.execute("INSERT INTO courses(name) VALUES('会计学')")
                conn.commit()
                conn.close()
            result = migrate(source, target)
            self.assertEqual(result['target'], str(target.resolve()))
            self.assertTrue((target / 'app' / 'banxue.db').exists())
            self.assertTrue((target / 'StudyPal' / '会计学' / 'notes.md').exists())
            self.assertTrue((target / 'lifepal' / 'notes' / 'record.md').exists())
            self.assertEqual(json.loads((target / 'app' / 'settings.json').read_text())['fast']['model'], 'local')


if __name__ == '__main__':
    unittest.main()
