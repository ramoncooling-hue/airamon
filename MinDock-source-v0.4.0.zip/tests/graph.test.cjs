const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const html = fs.readFileSync(path.join(__dirname, '../web/index.html'), 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];

test('graph supports two-hop traversal and explicit relation opening', () => {
  const start = script.indexOf('function graphNeighbors(');
  const end = script.indexOf('function clearGraphFocus', start);
  const context = vm.createContext({S: {graph: {edges: [
    {from_kp: 1, to_kp: 2}, {from_kp: 2, to_kp: 3}, {from_kp: 3, to_kp: 4}
  ]}}});
  vm.runInContext(script.slice(start, end), context);
  assert.deepEqual([...context.graphNeighbors(1, 2)].sort((a, b) => a - b), [1, 2, 3]);
  assert.match(script, /data-edge-focus=/);
  assert.match(script, /graphFocusStatus/);
  assert.match(script, /classList\.toggle\('trace'/);
});

test('graph has canonical chapter focus and an overview dot layout', () => {
  assert.match(script, /graphFocus:\{kind:'all',chapter:'',nodeId:null,depth:2\}/);
  assert.match(script, /data-graph-chapter=/);
  assert.match(script, /function graphFocusIds\(/);
  assert.match(script, /graphFocusIds\(g\)/);
  assert.match(script, /<circle class="gnode-dot"/);
  assert.match(script, /item\.classList\.toggle\('on', active\)/);
  assert.match(script, /item\.setAttribute\('aria-selected', active \? 'true' : 'false'\)/);
});
