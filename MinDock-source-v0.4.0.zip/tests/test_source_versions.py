import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from app.memory import db, sources


class SourceVersionTests(unittest.TestCase):
    def test_changed_file_keeps_previous_sha_version(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(db, 'APP_DIR', root / 'app'), patch.object(db, 'DB_PATH', root / 'app' / 'test.db'):
                db.apply_schema()
                conn = db.connect()
                conn.execute("INSERT INTO courses(name) VALUES('测试课程')")
                conn.commit()
                conn.close()
                inbox = root / '测试课程' / 'inbox'
                inbox.mkdir(parents=True)
                doc = inbox / 'lesson.md'
                doc.write_text('# 第一版\n内容一', encoding='utf-8')
                sources.scan_course('测试课程', [inbox])
                doc.write_text('# 第二版\n内容二', encoding='utf-8')
                sources.scan_course('测试课程', [inbox])
                conn = db.connect()
                try:
                    versions = conn.execute('SELECT COUNT(*) FROM source_versions').fetchone()[0]
                finally:
                    conn.close()
                self.assertEqual(versions, 2)

                conn = db.connect()
                try:
                    snapshot = conn.execute('SELECT sha256,raw_path,text_path FROM source_version_artifacts ORDER BY id LIMIT 1').fetchone()
                finally:
                    conn.close()
                self.assertTrue(Path(snapshot['raw_path']).exists())
                self.assertTrue(Path(snapshot['text_path']).exists())
                diff = sources.diff_versions('测试课程', str(doc.resolve()), snapshot['sha256'], 'latest')
                self.assertIn('-内容一', diff['diff'])
                self.assertIn('+内容二', diff['diff'])

    def test_unchanged_inbox_file_backfills_missing_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(db, 'APP_DIR', root / 'app'), patch.object(db, 'DB_PATH', root / 'app' / 'test.db'):
                db.apply_schema()
                conn = db.connect()
                conn.execute("INSERT INTO courses(name) VALUES('测试课程')")
                conn.commit()
                conn.close()
                inbox = root / '测试课程' / 'inbox'
                inbox.mkdir(parents=True)
                doc = inbox / 'lesson.md'
                doc.write_text('# 课程\n正文', encoding='utf-8')
                sources.scan_course('测试课程', [inbox])
                conn = db.connect()
                conn.execute('DELETE FROM source_version_artifacts')
                conn.commit()
                conn.close()
                self.assertEqual(sources.scan_course('测试课程', [inbox])['unchanged'], 1)
                conn = db.connect()
                try:
                    count = conn.execute('SELECT COUNT(*) FROM source_version_artifacts').fetchone()[0]
                finally:
                    conn.close()
                self.assertEqual(count, 1)

    def test_missing_inbox_file_becomes_stale(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(db, 'APP_DIR', root / 'app'), patch.object(db, 'DB_PATH', root / 'app' / 'test.db'):
                db.apply_schema()
                conn = db.connect()
                conn.execute("INSERT INTO courses(name) VALUES('测试课程')")
                conn.commit()
                conn.close()
                inbox = root / '测试课程' / 'inbox'
                inbox.mkdir(parents=True)
                doc = inbox / 'lesson.md'
                doc.write_text('# 课程', encoding='utf-8')
                sources.scan_course('测试课程', [inbox])
                doc.unlink()
                result = sources.scan_course('测试课程', [inbox])
                self.assertEqual(result['stale'], 1)
                self.assertEqual(sources.status('测试课程')[0]['status'], 'stale')

    def test_stale_file_can_be_restored_from_version_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(db, 'APP_DIR', root / 'app'), patch.object(db, 'DB_PATH', root / 'app' / 'test.db'):
                db.apply_schema()
                conn = db.connect()
                conn.execute("INSERT INTO courses(name) VALUES('测试课程')")
                conn.commit()
                conn.close()
                inbox = root / '测试课程' / 'inbox'
                inbox.mkdir(parents=True)
                doc = inbox / 'lesson.md'
                doc.write_text('# 可恢复\n原始内容', encoding='utf-8')
                sources.scan_course('测试课程', [inbox])
                conn = db.connect()
                sha = conn.execute('SELECT sha256 FROM source_versions ORDER BY id LIMIT 1').fetchone()['sha256']
                conn.close()
                doc.unlink()
                sources.scan_course('测试课程', [inbox])
                restored = sources.restore_version('测试课程', str(doc.resolve()), sha)
                self.assertEqual(restored['status'], 'indexed')
                self.assertIn('原始内容', doc.read_text(encoding='utf-8'))


if __name__ == '__main__':
    unittest.main()
