const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const html = fs.readFileSync(path.join(__dirname, '..', 'web', 'index.html'), 'utf8');

test('course page exposes absolute storage path and local folder actions', () => {
  assert.match(html, /id="runtimeDataPath"/);
  assert.match(html, /data-copy-path/);
  assert.match(html, /data-reveal-path/);
  assert.match(html, /\/api\/runtime\/reveal/);
});

test('course page shows material inventory and extraction quality state', () => {
  assert.match(html, /id="materialInventory"/);
  assert.match(html, /materials\|\|\[\]/);
  assert.match(html, /中文 OCR/);
  assert.match(html, /待识别/);
});

test('course actions use a stable right-aligned action rail', () => {
  assert.match(html, /\.source-row\{[^}]*display:grid/);
  assert.match(html, /source-row-actions/);
  assert.match(html, /grid-template-columns:repeat\(4/);
});
