const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const html = fs.readFileSync(require('node:path').join(__dirname, '../web/index.html'), 'utf8');
const block = html.slice(html.indexOf('let chatSending = false;'), html.indexOf('/** Safe Markdown'));

function setup(result){
  const posts=[], requests=[];
  const elements={chatGo:{disabled:false},chatIn:{value:'问题'}};
  const state={msgs:[{who:'me',text:'旧问题'},{who:'ai',text:'<p>旧答案</p>',rawText:'原始回答',webResults:[{title:'来源',url:'https://example.com'}]}],role:{name:'老巴助教',key:'laoba',model:'fast'},scope:'*',webMode:'auto',convId:1,page:'chat'};
  const context=vm.createContext({S:state,SCOPE_ALL:'*',API:'',TextDecoder,Uint8Array,JSON,
    el:id=>elements[id],ensureConv:async()=>1,persistMsg:async(id,p)=>posts.push(p),
    renderMessages(){},renderConvList(){},loadConvs:async()=>{},toast(){},
    messageRefs:message=>[...(message.cites||[]),...(message.manualResults||[]),...(message.webResults||[])],
    esc:s=>s,stripHtml:s=>s.replace(/<[^>]+>/g,''),mdToHtml:s=>'<p>'+s+'</p>',
    fetch:async(url,opts)=>{
      requests.push(JSON.parse(opts.body));
      const data='data: '+JSON.stringify({type:'tool',tool:'web_search',query:'Astra',status:'done',count:1})+'\n\n'+'data: '+JSON.stringify({type:'result',data:result})+'\n\n';
      const bytes=new TextEncoder().encode(data);
      return {ok:true,body:new ReadableStream({start(c){c.enqueue(bytes.slice(0,37));c.enqueue(bytes.slice(37));c.close();}})};
    }
  });
  vm.runInContext(block,context);
  return {context,state,posts,requests,elements};
}

test('chat preserves selected role and raw context, cites only backend evidence and saves sources', async()=>{
  const x=setup({engine:'model',text:'查到了 [网页1]',hits:[{id:5,name:'无关会计知识',citation:'记忆1'}],web_results:[{url:'https://example.com/astra',title:'Astra'}],trace:[]});
  await vm.runInContext("chatSend('新问题')",x.context);
  assert.equal(x.requests[0].role_key,'laoba');
  assert.equal(x.requests[0].history.length,2);
  assert.match(x.requests[0].history[1].content,/原始回答/);
  assert.match(x.requests[0].history[1].content,/https:\/\/example.com/);
  assert.equal(x.state.msgs.at(-1).cites.length,0);
  assert.doesNotMatch(x.state.msgs.at(-1).text,/依据上面/);
  assert.equal(x.posts[1].metadata.web_results[0].title,'Astra');
  assert.equal(x.elements.chatGo.disabled,false);
});

test('double Enter does not create duplicate model requests',async()=>{
  const x=setup({engine:'model',text:'回答'});
  await Promise.all([vm.runInContext("chatSend('一')",x.context),vm.runInContext("chatSend('二')",x.context)]);
  assert.equal(x.requests.length,1);
});

test('model failure is explicit rather than a fake locally composed answer',async()=>{
  const x=setup({engine:'local',text:'',error:'模型连接失败'});
  await vm.runInContext("chatSend('问题')",x.context);
  assert.equal(x.state.msgs.at(-1).engine,'error');
  assert.match(x.state.msgs.at(-1).text,/模型连接失败/);
});
