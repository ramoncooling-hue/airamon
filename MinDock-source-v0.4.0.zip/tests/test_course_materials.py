import base64
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from app.api import routes
from app.memory import db


class CourseMaterialSurfaceTests(unittest.TestCase):
    def test_course_status_exposes_absolute_storage_and_artifact_inventory(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(db, 'DATA_DIR', root), \
                 patch.object(db, 'APP_DIR', root / 'app'), \
                 patch.object(db, 'DB_PATH', root / 'app' / 'test.db'), \
                 patch.object(routes, 'STUDYPAL_DIR', root / 'StudyPal'):
                db.apply_schema()
                conn = db.connect()
                conn.execute("INSERT INTO courses(name) VALUES('会计学')")
                conn.commit()
                conn.close()
                payload = base64.b64encode('# 成本\n边际成本是新增一单位产量的成本。'.encode()).decode()
                result = routes.intake(routes.IntakeIn(
                    course='会计学', filename='lesson.md', content_base64=payload,
                    mime='text/markdown',
                ))
                status = routes.source_status('会计学')
                self.assertEqual(result['path'], str((root / 'StudyPal' / '会计学' / 'inbox' / 'lesson.md').resolve()))
                self.assertEqual(status['data_dir'], str(root.resolve()))
                self.assertEqual(status['course_dir'], str((root / 'StudyPal' / '会计学').resolve()))
                self.assertEqual(status['inbox_dir'], str((root / 'StudyPal' / '会计学' / 'inbox').resolve()))
                material = status['materials'][0]
                self.assertEqual(material['original_path'], result['path'])
                self.assertTrue(material['artifacts']['note']['exists'])
                self.assertTrue(material['artifacts']['dictionary']['exists'])

    def test_runtime_path_info_and_reveal_are_scoped_to_data_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            target = root / 'StudyPal' / '会计学' / 'inbox' / 'lesson.md'
            target.parent.mkdir(parents=True)
            target.write_text('材料', encoding='utf-8')
            with patch.object(db, 'DATA_DIR', root), \
                 patch('app.api.routes.platform.system', return_value='Darwin'), \
                 patch('app.api.routes.subprocess.Popen') as popen:
                info = routes.runtime_info()
                self.assertEqual(info['data_dir'], str(root))
                self.assertTrue(info['writable'])
                result = routes.runtime_reveal(routes.RevealIn(path=str(target)))
                self.assertTrue(result['ok'])
                popen.assert_called_once_with(['open', '-R', str(target)])
                with self.assertRaises(routes.HTTPException):
                    routes.runtime_reveal(routes.RevealIn(path='/tmp/outside.txt'))

    def test_assisted_draft_can_be_deleted_without_deleting_original(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(db, 'DATA_DIR', root), \
                 patch.object(db, 'APP_DIR', root / 'app'), \
                 patch.object(db, 'DB_PATH', root / 'app' / 'test.db'), \
                 patch.object(routes, 'STUDYPAL_DIR', root / 'StudyPal'):
                db.apply_schema()
                conn = db.connect()
                conn.execute("INSERT INTO courses(name) VALUES('会计学')")
                conn.commit()
                conn.close()
                payload = base64.b64encode('# 成本\n边际成本。'.encode()).decode()
                result = routes.intake(routes.IntakeIn(
                    course='会计学', filename='lesson.md', content_base64=payload,
                    mime='text/markdown',
                ))
                source = Path(result['path'])
                note = source.parent.parent / 'notes' / 'lesson.md'
                dictionary = source.parent.parent / 'dictionary' / 'lesson.json'
                note.write_text('draft', encoding='utf-8')
                dictionary.write_text('{}', encoding='utf-8')
                conn = db.connect()
                conn.execute("UPDATE knowledge_notes SET status='assisted_draft' WHERE path=?", (str(note),))
                conn.commit()
                conn.close()
                result = routes.delete_source_draft(routes.SourceDraftDeleteIn(course='会计学', path=str(source)))
                self.assertTrue(result['ok'])
                self.assertTrue(source.exists())
                self.assertFalse(note.exists())
                self.assertFalse(dictionary.exists())
                self.assertEqual(routes.source_status('会计学')['files'][0]['status'], 'indexed')


if __name__ == '__main__':
    unittest.main()
